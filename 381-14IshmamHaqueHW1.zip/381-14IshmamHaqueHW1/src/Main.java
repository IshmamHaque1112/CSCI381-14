import java.util.Random;
import java.util.*;
public class Main{
	public static void main(String[] args) {
	    int[] nodearray = new int[]{0,0,0,0,0};
	    double[] processarray= new double[5];
	    Random rand = new Random();
	    int clockchange=0;
	    boolean lessthan15=true;
	    for(int i=0;i<5;i++) {
	    	int randnum=rand.nextInt(1001);
			processarray[i]=Math.round(randnum*0.1*10)/10.0;
		}
	    System.out.println("Initial starting point");
	    for(int j=0;j<5;j++){
			  System.out.println("Job "+(j+1)+" : Node:"+(nodearray[j]+1)+" Next change: "+ processarray[j]);
		}
	    double counter1=Math.round(1*0.1*10)/10.0;
	    while(counter1<=10000.0) {
	      boolean diditmove=false;
	      int[] oldnodearray=new int[5];
	      for(int i=0;i<5;i++) oldnodearray[i]=nodearray[i];
	      for(int i=0;i<processarray.length;i++){
	    	double currmin=processarray[i];
		    int currpos=i;
	        if(counter1==currmin){    
	  	      nodearray[currpos]=((nodearray[currpos]+1)%5);
	  	      int randnum1=rand.nextInt(1001);
	  	      double newrand=Math.round(randnum1*0.1*10)/10.0;
		      processarray[currpos]=Math.round((currmin+newrand)*10)/10.0;
		      clockchange++;
		      diditmove=true;
	        }          
	      }
	      if(counter1%500.0==0.0){
	    	 System.out.println(counter1+" time units: ");
	    	 for(int j=0;j<5;j++){
	    	   System.out.println("Job "+(j+1)+" : Node:"+(nodearray[j]+1)+" Next change: "+processarray[j]);
	    	 }	
	       }
	       if(counter1==10000.0) break;
	      if(clockchange<=15&&lessthan15==true&&diditmove==true) {
		    System.out.println(counter1+" time units and Move: "+clockchange);
			for(int j=0;j<5;j++){
			  System.out.println("Job "+(j+1)+" : Node:"+(nodearray[j]+1)+" Next change: "+processarray[j]);
			}
			for(int j=0;j<5;j++) {
			  if((oldnodearray[j]+1)!=(nodearray[j]+1)) { 
			    System.out.println("Job "+(j+1)+" moved from "+(oldnodearray[j]+1)+" to "+(nodearray[j]+1));
			  }	
			}
			if(clockchange==15) lessthan15=false;
		  }
			 counter1=Math.round((counter1+0.1)*10)/10.0;
	    }
	    System.out.println("Final results:");
		for(int j=0;j<5;j++){
	     System.out.println("Job "+(j+1)+" : Node:"+(nodearray[j]+1));
		}
    }
}