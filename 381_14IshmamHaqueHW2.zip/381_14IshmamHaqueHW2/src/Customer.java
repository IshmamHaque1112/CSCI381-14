public class Customer {
 public int index;
 public double timeofjob;
 public double timecompleted=0.0;
 public double arrivaltime=0.0;
 public double exittime=0.0;
 public double leavetime=0.0;
 public double timeinserver=0.0;
 public double timeleft=0.0;
 public double serverremainder=0.0;
 public int leftservertime=0;
 public double fulltimewhencompleted;
 public boolean diditgoinside=false;
 Customer(int index){
  this.index=index;
 }
}
