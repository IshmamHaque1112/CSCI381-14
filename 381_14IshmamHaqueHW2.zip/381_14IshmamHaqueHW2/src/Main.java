import java.util.ArrayList;
import java.util.*;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
public class Main {
	public static Double intervaltime() {
		    double time=0.0;
		    while(time<=0.0) {
		     double generatednumber=ThreadLocalRandom.current().nextDouble(0,1.01);
		     while((generatednumber<=0)||(generatednumber>1)) generatednumber=ThreadLocalRandom.current().nextDouble(0,1.01);
		     generatednumber=Math.round(generatednumber*10000)/10000.0;
		     time=(-1*Math.log(1-generatednumber))*(15);
		     time=Math.round(time*10000)/10000.0;
		    }
			return time;
    }
	public static Double servicetime() {
		double time=0.0;
		while(time<=0.0) {
		 double generatednumber=ThreadLocalRandom.current().nextDouble(0,1.01);
	     while((generatednumber<=0)||(generatednumber>1)) generatednumber=ThreadLocalRandom.current().nextDouble(0,1.01);
	     generatednumber=Math.round(generatednumber*10000)/10000.0;
	     time=(-1*Math.log(1-generatednumber))*(20);
	     time=Math.round(time*10000)/10000.0;
		}
		return time;
    }
	public static void main(String[] args) {
       System.out.println("The first method attempts to process 10,000 customers by using the round robin method with a quantum of 1.5");
       Boolean server1=false;
       Boolean server2=false;
       Customer servingcustomer1=null;
       Customer servingcustomer2=null;       
       int numberofcustomersserved=0;
       int customernum=0;
       double timer=0.0;
       double oldtime=0.0;
       double timewhenintervalarrives=intervaltime();
       double mintime=0.0;
       double interval=0.0;
       double newtime=0.0;
       boolean diditchange=false;
       ArrayList<Customer> customerarray= new ArrayList<Customer>();
       ArrayList<Double> arrivaltimearray=new ArrayList<Double>();
       ArrayList<Double> exittimearray=new ArrayList<Double>();
       ArrayList<Double> jobtimearray=new ArrayList<Double>();
       ArrayList<Customer> finishedcustarray=new ArrayList<Customer>();
       //ArrayList<Double> mintimearray=new ArrayList<Double>();
       //ArrayList<Double> mintimearray0=new ArrayList<Double>();
       customernum++;
       Customer cust=new Customer(customernum);
       cust.arrivaltime=timewhenintervalarrives;
       cust.timeofjob=servicetime();
       cust.timeleft=cust.timeofjob;
       while(numberofcustomersserved<10000) {
         ArrayList<Double> mintimearray=new ArrayList<Double>();
         diditchange=false;
         if(server1==true){
        	 double timeprogress1=Math.round((servingcustomer1.timecompleted+mintime)*10000)/10000.0;
        	 servingcustomer1.timeinserver=Math.round((servingcustomer1.timeinserver+mintime)*10000)/10000.0;
        	 servingcustomer1.timeleft=Math.round((servingcustomer1.timeofjob-timeprogress1)*10000)/10000.0;
        	 servingcustomer1.timecompleted=timeprogress1;
        	 if(servingcustomer1.timecompleted>=servingcustomer1.timeofjob) {
        		 double difference=Math.round((timeprogress1-servingcustomer1.timeofjob)*10000)/10000.0;
        		 servingcustomer1.exittime=Math.round((timer-difference)*10000)/10000.0;
        		 servingcustomer1.leftservertime++;
    			 exittimearray.add(servingcustomer1.exittime);
    			 finishedcustarray.add(servingcustomer1);
    			 Customer exitcustomer=servingcustomer1;
    			 servingcustomer1=null;
    			 server1=false;
    			 diditchange=true;
    			 numberofcustomersserved++;
    			 if(customerarray.isEmpty()==false) {
    	              Customer poppedcust1=customerarray.get(customerarray.size()-1);
    	              customerarray.remove(customerarray.size()-1);
    	              while(poppedcust1==null && customerarray.isEmpty()==false) {
    	            	  poppedcust1=customerarray.remove(customerarray.size()-1);
    	              }
    	              if(poppedcust1!=null) {
    	        	  servingcustomer1=poppedcust1;
    	        	  servingcustomer1.diditgoinside=true;
    	        	  servingcustomer1.serverremainder=1.5;
    	        	  servingcustomer1.leavetime=1.5;
    	        	  if(servingcustomer1.timeofjob<1.5) {
    	        		  servingcustomer1.serverremainder=servingcustomer1.timeofjob;
    	        		  servingcustomer1.leavetime=servingcustomer1.timeofjob;
    	        	  }
    	        	  server1=true;
    	             }
    	         }
    			 if(exitcustomer.index<=15) {
    	             System.out.println("------------------------------------------------------------------------");
    	        	 System.out.println("Round Robin: Departing System from Server 1 Event has occurred Timer: "+exitcustomer.exittime);
    	   			 System.out.print(" Printing Departing Customer: "+exitcustomer.index);
    	   			 System.out.print(" Job Time "+exitcustomer.timeofjob+" Arrival: "+exitcustomer.arrivaltime); 				  
    	        	 System.out.println();
    	        	 System.out.println("Round Robin: Printing All Future Customers Current Customers Served: "+numberofcustomersserved);
    	        	 System.out.println("Timer: "+timer);
    	        	 if(servingcustomer1!=null) {
    	            	 System.out.println("---");
    	            	 System.out.print("Round Robin Server 1: ");
    	            	 System.out.print(" Customer Event Number :  "+servingcustomer1.index);
    	    			 System.out.print(" Arrival Time: "+servingcustomer1.arrivaltime);
    	    			 System.out.print(" Job Time: "+servingcustomer1.timeofjob);
    	    			 System.out.print(" Remaining Job Time: "+servingcustomer1.timeleft);
    	    			 System.out.println();
    	        	 }
    	        	 if(servingcustomer2!=null) {
    	            	 System.out.println("---");
    	            	 System.out.print("Round Robin Server 2: ");
    	            	 System.out.print(" Customer Event Number :  "+servingcustomer2.index);
    	    			 System.out.print(" Arrival Time: "+servingcustomer2.arrivaltime);
    	    			 System.out.print(" Job Time: "+servingcustomer2.timeofjob);
    	    			 System.out.print(" Remaining Job Time: "+servingcustomer2.timeleft);
    	    			 System.out.println();
    	        	 }
    	        	 if(cust!=null) {
    	            	 System.out.println("---");
    	            	 System.out.print("Next Arriving Round Robin Customer: ");
    	            	 System.out.print(" Customer Event Number:  "+cust.index);
    	    			 System.out.print(" Arrival Time: "+cust.arrivaltime);
    	    			 System.out.print(" Job Time: "+cust.timeofjob);
    	    			 System.out.print(" Remaining Job Time (Same as Job Time): "+cust.timeleft);
    	    			 System.out.println();
    	        	 }
    	        	 System.out.println("Round Robin: Printing All Delayed Customers Current Customers Served: "+numberofcustomersserved);
    	        	 System.out.println("Timer: "+timer);
    	        	 if(customerarray.size()==0) System.out.println("Delayed list is empty");
    	        	 for(int i=customerarray.size()-1;0<=i;i--) {
    	                	 System.out.println("---");
    	        			 System.out.print("Customer Event Number :  "+customerarray.get(i).index);
    	        			 System.out.print(" Arrival Time: "+customerarray.get(i).arrivaltime);
    	        			 System.out.print(" Job Time: "+customerarray.get(i).timeofjob);
    	        			 System.out.print(" Remaining Job Time: "+customerarray.get(i).timeleft);
    	        			 System.out.println();
    	        	 }
    	        	 System.out.println("------------------------------------------------------------------------");	 
    	            }
    			 
    		 }
        	 else if(servingcustomer1.timeinserver>=servingcustomer1.leavetime) {
        	 servingcustomer1.timeinserver=0.0;
        	 servingcustomer1.leavetime=0.0;
        	 servingcustomer1.leftservertime++;
             customerarray.add(0,servingcustomer1);
             Customer exitcustomer=servingcustomer1;
        	 servingcustomer1=null;
        	 server1=false; 
        	 if(customerarray.isEmpty()==false) {
	              Customer poppedcust1=customerarray.get(customerarray.size()-1);
	              customerarray.remove(customerarray.size()-1);
	              while(poppedcust1==null && customerarray.isEmpty()==false) {
	            	  poppedcust1=customerarray.remove(customerarray.size()-1);
	              }
	              if(poppedcust1!=null) {
	        	  servingcustomer1=poppedcust1;
	        	  servingcustomer1.diditgoinside=true;
	        	  servingcustomer1.serverremainder=1.5;
	        	  servingcustomer1.leavetime=1.5;
	        	  if(servingcustomer1.timeofjob<1.5) {
	        		  servingcustomer1.serverremainder=servingcustomer1.timeofjob;
	        		  servingcustomer1.leavetime=servingcustomer1.timeofjob;
	        	  }
	        	  server1=true;
	             }
	         }
        	 if(exitcustomer.index<=15) {
	             System.out.println("------------------------------------------------------------------------");
	        	 System.out.println("Round Robin: A Job in Server 1 needs more service time and is being booted to delayed queue Event has occurred Timer: "+timer);
	   			 System.out.print(" Printing Booted Customer: "+exitcustomer.index);
	   			 System.out.print(" Job Time "+exitcustomer.timeofjob+" Arrival: "+exitcustomer.arrivaltime+" Remaining Job Time: "+exitcustomer.timeleft); 				  
	        	 System.out.println();
	        	 System.out.println("Round Robin: Printing All Future Customers Current Customers Served: "+numberofcustomersserved);
	        	 System.out.println("Timer: "+timer);
	        	 if(servingcustomer1!=null) {
	            	 System.out.println("---");
	            	 System.out.print("Round Robin Server 1: ");
	            	 System.out.print(" Customer Event Number :  "+servingcustomer1.index);
	    			 System.out.print(" Arrival Time: "+servingcustomer1.arrivaltime);
	    			 System.out.print(" Job Time: "+servingcustomer1.timeofjob);
	    			 System.out.print(" Remaining Job Time: "+servingcustomer1.timeleft);
	    			 System.out.println();
	        	 }
	        	 if(servingcustomer2!=null) {
	            	 System.out.println("---");
	            	 System.out.print("Round Robin Server 2: ");
	            	 System.out.print(" Customer Event Number :  "+servingcustomer2.index);
	    			 System.out.print(" Arrival Time: "+servingcustomer2.arrivaltime);
	    			 System.out.print(" Job Time: "+servingcustomer2.timeofjob);
	    			 System.out.print(" Remaining Job Time: "+servingcustomer2.timeleft);
	    			 System.out.println();
	        	 }
	        	 if(cust!=null) {
	            	 System.out.println("---");
	            	 System.out.print("Next Arriving Round Robin Customer: ");
	            	 System.out.print(" Customer Event Number:  "+cust.index);
	    			 System.out.print(" Arrival Time: "+cust.arrivaltime);
	    			 System.out.print(" Job Time: "+cust.timeofjob);
	    			 System.out.print(" Remaining Job Time (Same as Job Time): "+cust.timeleft);
	    			 System.out.println();
	        	 }
						/*
						 * System.out.
						 * println("Round Robin: Printing All Delayed Customers Current Customers Served: "
						 * +numberofcustomersserved); System.out.println("Timer: "+timer);
						 * if(customerarray.size()==0) System.out.println("Delayed list is empty");
						 * for(int i=customerarray.size()-1;0<=i;i--) { System.out.println("---");
						 * System.out.print("Customer Event Number :  "+customerarray.get(i).index);
						 * System.out.print(" Arrival Time: "+customerarray.get(i).arrivaltime);
						 * System.out.print(" Job Time: "+customerarray.get(i).timeofjob);
						 * System.out.print(" Remaining Job Time: "+customerarray.get(i).timeleft);
						 * System.out.println(); }
						 */
	        	 System.out.println("------------------------------------------------------------------------");	 
	            }
        	 }
        	 else if(servingcustomer1.timeinserver<servingcustomer1.leavetime) {
        	  servingcustomer1.serverremainder=Math.round((servingcustomer1.leavetime-servingcustomer1.timeinserver)*10000)/10000.0;
        	  //System.out.println("server 1");
        	 }
         }
         if(server2==true){
        	 double timeprogress2=Math.round((servingcustomer2.timecompleted+mintime)*10000)/10000.0;
        	 servingcustomer2.timeinserver=Math.round((servingcustomer2.timeinserver+mintime)*10000)/10000.0;
        	 servingcustomer2.timeleft=Math.round((servingcustomer2.timeofjob-timeprogress2)*10000)/10000.0;
        	 servingcustomer2.timecompleted=timeprogress2;
        	 if(servingcustomer2.timecompleted>=servingcustomer2.timeofjob) {
        		 double difference=Math.round((timeprogress2-servingcustomer2.timeofjob)*10000)/10000.0;
        		 servingcustomer2.exittime=Math.round((timer-difference)*10000)/10000.0;
        		 servingcustomer2.leftservertime++;
    			 exittimearray.add(servingcustomer2.exittime);
    			 finishedcustarray.add(servingcustomer2);
    			 Customer exitcustomer=servingcustomer2;
    			 servingcustomer2=null;
    			 server2=false;
    			 diditchange=true;
    			 numberofcustomersserved++;
    			 if(customerarray.isEmpty()==false) {
    	              Customer poppedcust2=customerarray.get(customerarray.size()-1);
    	              customerarray.remove(customerarray.size()-1);
    	              while(poppedcust2==null && customerarray.isEmpty()==false) {
    	            	  poppedcust2=customerarray.remove(customerarray.size()-1);
    	              }
    	              if(poppedcust2!=null) {
    	              servingcustomer2=poppedcust2;
    	        	  servingcustomer2.diditgoinside=true;
    	        	  servingcustomer2.serverremainder=1.5;
    	        	  servingcustomer2.leavetime=1.5;
    	        	  if(servingcustomer2.timeofjob<1.5) { 
    	        		  servingcustomer2.serverremainder=servingcustomer2.timeofjob;
    	        		  servingcustomer2.leavetime=servingcustomer2.timeofjob;
    	        	  }
    	        	  server2=true;
    	             }
    	         }
    			 if(exitcustomer.index<=15) {
    	             System.out.println("------------------------------------------------------------------------");
    	        	 System.out.println("Round Robin: Departing System from Server 2 Event has occurred Timer: "+exitcustomer.exittime);
    	   			 System.out.print(" Printing Departing Customer: "+exitcustomer.index);
    	   			 System.out.print(" Job Time "+exitcustomer.timeofjob+" Arrival: "+exitcustomer.arrivaltime); 				  
    	        	 System.out.println();
    	        	 System.out.println("Round Robin: Printing All Future Customers Current Customers Served: "+numberofcustomersserved);
    	        	 System.out.println("Timer: "+timer);
    	        	 if(servingcustomer1!=null) {
    	            	 System.out.println("---");
    	            	 System.out.print("Round Robin Server 1: ");
    	            	 System.out.print(" Customer Event Number :  "+servingcustomer1.index);
    	    			 System.out.print(" Arrival Time: "+servingcustomer1.arrivaltime);
    	    			 System.out.print(" Job Time: "+servingcustomer1.timeofjob);
    	    			 System.out.print(" Remaining Job Time: "+servingcustomer1.timeleft);
    	    			 System.out.println();
    	        	 }
    	        	 if(servingcustomer2!=null) {
    	            	 System.out.println("---");
    	            	 System.out.print("Round Robin Server 2: ");
    	            	 System.out.print(" Customer Event Number :  "+servingcustomer2.index);
    	    			 System.out.print(" Arrival Time: "+servingcustomer2.arrivaltime);
    	    			 System.out.print(" Job Time: "+servingcustomer2.timeofjob);
    	    			 System.out.print(" Remaining Job Time: "+servingcustomer2.timeleft);
    	    			 System.out.println();
    	        	 }
    	        	 if(cust!=null) {
    	            	 System.out.println("---");
    	            	 System.out.print("Next Arriving Round Robin Customer: ");
    	            	 System.out.print(" Customer Event Number:  "+cust.index);
    	    			 System.out.print(" Arrival Time: "+cust.arrivaltime);
    	    			 System.out.print(" Job Time: "+cust.timeofjob);
    	    			 System.out.print(" Remaining Job Time (Same as Job Time): "+cust.timeleft);
    	    			 System.out.println();
    	        	 }
    	        	 System.out.println("Round Robin: Printing All Delayed Customers Current Customers Served: "+numberofcustomersserved);
    	        	 System.out.println("Timer: "+timer);
    	        	 if(customerarray.size()==0) System.out.println("Delayed list is empty");
    	        	 for(int i=customerarray.size()-1;0<=i;i--) {
    	                	 System.out.println("---");
    	        			 System.out.print("Customer Event Number :  "+customerarray.get(i).index);
    	        			 System.out.print(" Arrival Time: "+customerarray.get(i).arrivaltime);
    	        			 System.out.print(" Job Time: "+customerarray.get(i).timeofjob);
    	        			 System.out.print(" Remaining Job Time: "+customerarray.get(i).timeleft);
    	        			 System.out.println();
    	        	 }
    	        	 System.out.println("------------------------------------------------------------------------");	 
    	            }
    		 }
        	 else if(servingcustomer2.timeinserver>=servingcustomer2.leavetime) {
        	 servingcustomer2.timeinserver=0.0;
        	 servingcustomer2.leavetime=0.0;
        	 servingcustomer2.leftservertime++;
             customerarray.add(0,servingcustomer2);	
             Customer exitcustomer=servingcustomer2;
        	 servingcustomer2=null;
        	 server2=false; 
        	 if(customerarray.isEmpty()==false) {
	              Customer poppedcust2=customerarray.get(customerarray.size()-1);
	              customerarray.remove(customerarray.size()-1);
	              while(poppedcust2==null && customerarray.isEmpty()==false) {
	            	  poppedcust2=customerarray.remove(customerarray.size()-1);
	              }
	              if(poppedcust2!=null) {
	              servingcustomer2=poppedcust2;
	        	  servingcustomer2.diditgoinside=true;
	        	  servingcustomer2.serverremainder=1.5;
	        	  servingcustomer2.leavetime=1.5;
	        	  if(servingcustomer2.timeofjob<1.5) { 
	        		  servingcustomer2.serverremainder=servingcustomer2.timeofjob;
	        		  servingcustomer2.leavetime=servingcustomer2.timeofjob;
	        	  }
	        	  server2=true;
	             }
	         }
        	 if(exitcustomer.index<=15) {
	             System.out.println("------------------------------------------------------------------------");
	        	 System.out.println("Round Robin: A Job in Server 2 needs more service time and is being booted to delayed queue Event has occurred Timer: "+timer);
	   			 System.out.print(" Printing Booted Customer: "+exitcustomer.index);
	   			 System.out.print(" Job Time "+exitcustomer.timeofjob+" Arrival: "+exitcustomer.arrivaltime+" Remaining Job Time: "+exitcustomer.timeleft); 				  
	        	 System.out.println();
	        	 System.out.println("Round Robin: Printing All Future Customers Current Customers Served: "+numberofcustomersserved);
	        	 System.out.println("Timer: "+timer);
	        	 if(servingcustomer1!=null) {
	            	 System.out.println("---");
	            	 System.out.print("Round Robin Server 1: ");
	            	 System.out.print(" Customer Event Number :  "+servingcustomer1.index);
	    			 System.out.print(" Arrival Time: "+servingcustomer1.arrivaltime);
	    			 System.out.print(" Job Time: "+servingcustomer1.timeofjob);
	    			 System.out.print(" Remaining Job Time: "+servingcustomer1.timeleft);
	    			 System.out.println();
	        	 }
	        	 if(servingcustomer2!=null) {
	            	 System.out.println("---");
	            	 System.out.print("Round Robin Server 2: ");
	            	 System.out.print(" Customer Event Number :  "+servingcustomer2.index);
	    			 System.out.print(" Arrival Time: "+servingcustomer2.arrivaltime);
	    			 System.out.print(" Job Time: "+servingcustomer2.timeofjob);
	    			 System.out.print(" Remaining Job Time: "+servingcustomer2.timeleft);
	    			 System.out.println();
	        	 }
	        	 if(cust!=null) {
	            	 System.out.println("---");
	            	 System.out.print("Next Arriving Round Robin Customer: ");
	            	 System.out.print(" Customer Event Number:  "+cust.index);
	    			 System.out.print(" Arrival Time: "+cust.arrivaltime);
	    			 System.out.print(" Job Time: "+cust.timeofjob);
	    			 System.out.print(" Remaining Job Time (Same as Job Time): "+cust.timeleft);
	    			 System.out.println();
	        	 }
						/*
						 * System.out.
						 * println("Round Robin: Printing All Delayed Customers Current Customers Served: "
						 * +numberofcustomersserved); System.out.println("Timer: "+timer);
						 * if(customerarray.size()==0) System.out.println("Delayed list is empty");
						 * for(int i=customerarray.size()-1;0<=i;i--) { System.out.println("---");
						 * System.out.print("Customer Event Number :  "+customerarray.get(i).index);
						 * System.out.print(" Arrival Time: "+customerarray.get(i).arrivaltime);
						 * System.out.print(" Job Time: "+customerarray.get(i).timeofjob);
						 * System.out.print(" Remaining Job Time: "+customerarray.get(i).timeleft);
						 * System.out.println(); }
						 */
	        	 System.out.println("------------------------------------------------------------------------");	 
	            }
        	 }
        	 else if(servingcustomer2.timeinserver<servingcustomer2.leavetime) {
        	  servingcustomer2.serverremainder=Math.round((servingcustomer2.leavetime-servingcustomer2.timeinserver)*10000)/10000.0;
        	  //System.out.println("server 2");
        	 }
         }
         if(server1==false) {
        	 if(customerarray.isEmpty()==false) {
              Customer poppedcust1=customerarray.get(customerarray.size()-1);
              customerarray.remove(customerarray.size()-1);
              while(poppedcust1==null && customerarray.isEmpty()==false) {
            	  poppedcust1=customerarray.remove(customerarray.size()-1);
              }
              if(poppedcust1!=null) {
        	  servingcustomer1=poppedcust1;
        	  servingcustomer1.diditgoinside=true;
        	  servingcustomer1.serverremainder=1.5;
        	  servingcustomer1.leavetime=1.5;
        	  if(servingcustomer1.timeofjob<1.5) {
        		  servingcustomer1.serverremainder=servingcustomer1.timeofjob;
        		  servingcustomer1.leavetime=servingcustomer1.timeofjob;
        	  }
        	  server1=true;
        	 }
        	 }
         }
         if(server2==false) {
        	 if(customerarray.isEmpty()==false) {
              Customer poppedcust2=customerarray.get(customerarray.size()-1);
              customerarray.remove(customerarray.size()-1);
              while(poppedcust2==null && customerarray.isEmpty()==false) {
            	  poppedcust2=customerarray.remove(customerarray.size()-1);
              }
              if(poppedcust2!=null) {
        	  servingcustomer2=poppedcust2;
        	  servingcustomer2.diditgoinside=true;
        	  servingcustomer2.serverremainder=1.5;
        	  servingcustomer2.leavetime=1.5;
        	  if(servingcustomer2.timeofjob<1.5) { 
        		  servingcustomer2.serverremainder=servingcustomer2.timeofjob;
        		  servingcustomer2.leavetime=servingcustomer2.timeofjob;
        	  }
        	  server2=true;
        	 }
        	 }
         }
        int totalnumberofunserved=0;
        int totalnumberofdelayed=0;
         for(int i=0;i<customerarray.size();i++) {
        	 if(customerarray.get(i).diditgoinside==false) totalnumberofunserved++;
        	 if(customerarray.get(i).diditgoinside==true) totalnumberofdelayed++;
         }
         if(timewhenintervalarrives<=timer){
             //jobtimearray.add(cust.timeofjob);
             //arrivaltimearray.add(timewhenintervalarrives);
        	 customerarray.add(0,cust);
        	 if(server1==false) {
            	 if(customerarray.isEmpty()==false) {
                  Customer poppedcust1=customerarray.get(customerarray.size()-1);
                  customerarray.remove(customerarray.size()-1);
                  while(poppedcust1==null && customerarray.isEmpty()==false) {
                	  poppedcust1=customerarray.remove(customerarray.size()-1);
                  }
                  if(poppedcust1!=null) {
            	  servingcustomer1=poppedcust1;
            	  servingcustomer1.diditgoinside=true;
            	  servingcustomer1.serverremainder=1.5;
            	  servingcustomer1.leavetime=1.5;
            	  if(servingcustomer1.timeofjob<1.5) {
            		  servingcustomer1.serverremainder=servingcustomer1.timeofjob;
            		  servingcustomer1.leavetime=servingcustomer1.timeofjob;
            	  }
            	  server1=true;
            	 }
            	 }
             }
             if(server2==false) {
            	 if(customerarray.isEmpty()==false) {
                  Customer poppedcust2=customerarray.get(customerarray.size()-1);
                  customerarray.remove(customerarray.size()-1);
                  while(poppedcust2==null && customerarray.isEmpty()==false) {
                	  poppedcust2=customerarray.remove(customerarray.size()-1);
                  }
                  if(poppedcust2!=null) {
            	  servingcustomer2=poppedcust2;
            	  servingcustomer2.diditgoinside=true;
            	  servingcustomer2.serverremainder=1.5;
            	  servingcustomer2.leavetime=1.5;
            	  if(servingcustomer2.timeofjob<1.5) { 
            		  servingcustomer2.serverremainder=servingcustomer2.timeofjob;
            		  servingcustomer2.leavetime=servingcustomer2.timeofjob;
            	  }
            	  server2=true;
            	 }
            	 }
             }
            // else customerarray.add(0,cust);
             Customer oldcust=cust;
             customernum++;
             cust=new Customer(customernum);
             while(interval==0.0) interval=intervaltime();
             timewhenintervalarrives=Math.round((timer+interval)*10000)/10000.0;
             cust.arrivaltime=timewhenintervalarrives;
             cust.timeofjob=servicetime();
             cust.timeleft=cust.timeofjob;
             if(oldcust.index<=15) {
             System.out.println("------------------------------------------------------------------------");
        	 System.out.println("Round Robin: Arrival Event has occurred Timer: "+timer);
   			 System.out.print("Printing Arrived Customer: "+oldcust.index);
   			 System.out.print(" Job Time "+oldcust.timeofjob+" Arrival: "+oldcust.arrivaltime); 				  
        	 System.out.println();
        	 System.out.println("Round Robin: Printing All Future Customers Current Customers Served: "+numberofcustomersserved+" Current Event Number: "+oldcust.index);
        	 System.out.println("Timer: "+timer);
        	 if(servingcustomer1!=null) {
            	 System.out.println("---");
            	 System.out.print("Round Robin Server 1: ");
            	 System.out.print(" Customer Event Number :  "+servingcustomer1.index);
    			 System.out.print(" Arrival Time: "+servingcustomer1.arrivaltime);
    			 System.out.print(" Job Time: "+servingcustomer1.timeofjob);
    			 System.out.print(" Remaining Job Time: "+servingcustomer1.timeleft);
    			 System.out.println();
        	 }
        	 if(servingcustomer2!=null) {
            	 System.out.println("---");
            	 System.out.print("Round Robin Server 2: ");
            	 System.out.print(" Customer Event Number :  "+servingcustomer2.index);
    			 System.out.print(" Arrival Time: "+servingcustomer2.arrivaltime);
    			 System.out.print(" Job Time: "+servingcustomer2.timeofjob);
    			 System.out.print(" Remaining Job Time: "+servingcustomer2.timeleft);
    			 System.out.println();
        	 }
        	 if(cust!=null) {
            	 System.out.println("---");
            	 System.out.print("Next Arriving Round Robin Customer: ");
            	 System.out.print(" Customer Event Number:  "+cust.index);
    			 System.out.print(" Arrival Time: "+cust.arrivaltime);
    			 System.out.print(" Job Time: "+cust.timeofjob);
    			 System.out.print(" Remaining Job Time (Same as Job Time): "+cust.timeleft);
    			 System.out.println();
        	 }
        	 System.out.println("Round Robin: Printing All Delayed Customers Current Customers Served: "+numberofcustomersserved+" Current Event Number: "+oldcust.index);
        	 System.out.println("Timer: "+timer);
        	 if(customerarray.size()==0) System.out.println("Delayed list is empty");
        	 for(int i=customerarray.size()-1;0<=i;i--) {
                	 System.out.println("---");
        			 System.out.print("Customer Event Number :  "+customerarray.get(i).index);
        			 System.out.print(" Arrival Time: "+customerarray.get(i).arrivaltime);
        			 System.out.print(" Job Time: "+customerarray.get(i).timeofjob);
        			 System.out.print(" Remaining Job Time: "+customerarray.get(i).timeleft);
        			 System.out.println();
        	 }
        	 System.out.println("------------------------------------------------------------------------");	 
            }
             //customerarray.add(0,oldcust);
             }
         if(servingcustomer1!=null) mintimearray.add(servingcustomer1.serverremainder);
         if(servingcustomer2!=null) mintimearray.add(servingcustomer2.serverremainder);
         double untilinterval= Math.round((timewhenintervalarrives-timer)*10000)/10000.0;
         //if(mintimearray.isEmpty()==true) mintimearray.add(untilinterval);
         mintimearray.add(untilinterval);
         mintime=Collections.min(mintimearray);
         newtime=Math.round((timer+mintime)*10000)/10000.0;
         oldtime=timer;
         timer=newtime;
       }
       System.out.println("This prints the first 15 customers in round robin (by index which is by order of entering system, not exit)");
       for(int i=1;i<=15;i++) {
    	 for(int j=0;j<finishedcustarray.size();j++) {
    	    if(finishedcustarray.get(j).index==i) {
    	      System.out.print("Round Robin Customer Event Number (Index) "+finishedcustarray.get(j).index);
    	      System.out.print(" Job Time "+finishedcustarray.get(j).timeofjob+" Arrival: "+finishedcustarray.get(j).arrivaltime+" Exit: "+finishedcustarray.get(j).exittime);
    	      System.out.print(" Time in System excluding service: "+(Math.round((finishedcustarray.get(j).exittime-finishedcustarray.get(j).arrivaltime-finishedcustarray.get(j).timeofjob)*10000.0)/10000.0));
    	      System.out.println(" ");
    	      break;
    	    }
    	 } 
       }
       System.out.println("The second method attempts to process 10,000 customers by using the first come, first serve method with a quantum of 1000000000");
       Boolean server11=false;
       Boolean server21=false;
       Customer servingcustomer11=null;
       Customer servingcustomer21=null;       
       int numberofcustomersserved1=0;
       int customernum1=0;
       double timer1=0.0;
       double oldtime1=0.0;
       double timewhenintervalarrives1=intervaltime();
       double mintime1=0.0;
       double interval1=0.0;
       double newtime1=0.0;
       boolean diditchange1=false;
       ArrayList<Customer> customerarray1= new ArrayList<Customer>();
       ArrayList<Double> arrivaltimearray1=new ArrayList<Double>();
       ArrayList<Double> exittimearray1=new ArrayList<Double>();
       ArrayList<Double> jobtimearray1=new ArrayList<Double>();
       ArrayList<Customer> finishedcustarray1=new ArrayList<Customer>();
       customernum1++;
       Customer cust1=new Customer(customernum1);
       cust1.arrivaltime=timewhenintervalarrives1;
       cust1.timeofjob=servicetime();
       cust1.timeleft=cust1.timeofjob;
       while(numberofcustomersserved1<10000) {
         ArrayList<Double> mintimearray1=new ArrayList<Double>();
         diditchange1=false;
         
         if(server11==true){
        	 double timeprogress11=Math.round((servingcustomer11.timecompleted+mintime1)*10000)/10000.0;
        	 servingcustomer11.timeinserver=Math.round((servingcustomer11.timeinserver+mintime1)*10000)/10000.0;
        	 servingcustomer11.timeleft=Math.round((servingcustomer11.timeofjob-timeprogress11)*10000)/10000.0;
        	 servingcustomer11.timecompleted=timeprogress11;
        	 if(servingcustomer11.timecompleted>=servingcustomer11.timeofjob) {
        		 double difference=Math.round((timeprogress11-servingcustomer11.timeofjob)*10000)/10000.0;
        		 servingcustomer11.exittime=Math.round((timer1-difference)*10000)/10000.0;
        		 servingcustomer11.leftservertime++;
    			 exittimearray1.add(servingcustomer11.exittime);
    			 finishedcustarray1.add(servingcustomer11);
    			 Customer exitcustomer=servingcustomer11;
    			 servingcustomer11=null;
    			 server11=false;
    			 diditchange1=true;
    			 numberofcustomersserved1++;
    			 if(customerarray1.size()!=0) {
    	              Customer poppedcust11=customerarray1.get(customerarray1.size()-1);
    	              customerarray1.remove(customerarray1.size()-1);
    	              while(poppedcust11==null && customerarray1.isEmpty()==false) {
    	            	  poppedcust11=customerarray1.remove(customerarray1.size()-1);
    	              }
    	              if(poppedcust11!=null) {
    	        	  servingcustomer11=poppedcust11;
    	        	  servingcustomer11.diditgoinside=true;
    	        	  servingcustomer11.serverremainder=1000000000.0;
    	        	  servingcustomer11.leavetime=1000000000.0;
    	        	  if(servingcustomer11.timeofjob<1000000000.0) {
    	        		  servingcustomer11.serverremainder=servingcustomer11.timeofjob;
    	        		  servingcustomer11.leavetime=servingcustomer11.timeofjob;
    	        	  }
    	        	  server11=true;
    	        	 }
    	         }
    			 if(exitcustomer.index<=15) {
    	             System.out.println("------------------------------------------------------------------------");
    	        	 System.out.println("FCFS: Departing System from Server 1 Event has occurred Timer: "+exitcustomer.exittime);
    	   			 System.out.print(" Printing Departing Customer: "+exitcustomer.index);
    	   			 System.out.print(" Job Time "+exitcustomer.timeofjob+" Arrival: "+exitcustomer.arrivaltime); 				  
    	        	 System.out.println();
    	        	 System.out.println("FCFS: Printing All Future Customers Current Customers Served: "+numberofcustomersserved1);
    	        	 System.out.println("Timer: "+timer1);
    	        	 if(servingcustomer11!=null) {
    	            	 System.out.println("---");
    	            	 System.out.print("FCFS Server 1: ");
    	            	 System.out.print(" Customer Event Number :  "+servingcustomer11.index);
    	    			 System.out.print(" Arrival Time: "+servingcustomer11.arrivaltime);
    	    			 System.out.print(" Job Time: "+servingcustomer11.timeofjob);
    	    			 System.out.print(" Remaining Job Time: "+servingcustomer11.timeleft);
    	    			 System.out.print(" Exit Time: "+(Math.round((servingcustomer11.timeleft+timer1)*10000)/10000.0));
    	    			 System.out.println();
    	        	 }
    	        	 if(servingcustomer21!=null) {
    	            	 System.out.println("---");
    	            	 System.out.print("FCFS Server 2: ");
    	            	 System.out.print(" Customer Event Number :  "+servingcustomer21.index);
    	    			 System.out.print(" Arrival Time: "+servingcustomer21.arrivaltime);
    	    			 System.out.print(" Job Time: "+servingcustomer21.timeofjob);
    	    			 System.out.print(" Remaining Job Time: "+servingcustomer21.timeleft);
    	    			 System.out.print(" Exit Time: "+(Math.round((servingcustomer21.timeleft+timer1)*10000)/10000.0));
    	    			 System.out.println();
    	        	 }
    	        	 if(cust1!=null) {
    	            	 System.out.println("---");
    	            	 System.out.print("Next Arriving FCFS Customer: ");
    	            	 System.out.print(" Customer Event Number:  "+cust1.index);
    	    			 System.out.print(" Arrival Time: "+cust1.arrivaltime);
    	    			 System.out.print(" Job Time: "+cust1.timeofjob);
    	    			 System.out.print(" Remaining Job Time (Same as Job Time): "+cust1.timeleft);
    	    			 System.out.println();
    	        	 }
    	        	 System.out.println("FCFS: Printing All Delayed Customers Current Customers Served: "+numberofcustomersserved1);
    	        	 System.out.println("Timer: "+timer1);
    	        	 if(customerarray1.size()==0) System.out.println("Delayed list is empty");
    	        	 for(int i=customerarray1.size()-1;0<=i;i--) {
    	                	 System.out.println("---");
    	        			 System.out.print("Customer Event Number :  "+customerarray1.get(i).index);
    	        			 System.out.print(" Arrival Time: "+customerarray1.get(i).arrivaltime);
    	        			 System.out.print(" Job Time: "+customerarray1.get(i).timeofjob);
    	        			 System.out.print(" Remaining Job Time: "+customerarray1.get(i).timeleft);
    	        			 System.out.println();
    	        	 }
    	        	 System.out.println("------------------------------------------------------------------------");	 
    	            }
    			 
    		 }
        	 else if(servingcustomer11.timeinserver>=servingcustomer11.leavetime) {
        	 servingcustomer11.timeinserver=0.0;
        	 servingcustomer11.leavetime=0.0;
        	 servingcustomer11.leftservertime++;
             customerarray1.add(0,servingcustomer11);
             Customer exitcustomer=servingcustomer11;
        	 servingcustomer11=null;
        	 server11=false; 
        	 if(customerarray1.size()!=0) {
	              Customer poppedcust11=customerarray1.get(customerarray1.size()-1);
	              customerarray1.remove(customerarray1.size()-1);
	              while(poppedcust11==null && customerarray1.isEmpty()==false) {
	            	  poppedcust11=customerarray1.remove(customerarray1.size()-1);
	              }
	              if(poppedcust11!=null) {
	        	  servingcustomer11=poppedcust11;
	        	  servingcustomer11.diditgoinside=true;
	        	  servingcustomer11.serverremainder=1000000000.0;
	        	  servingcustomer11.leavetime=1000000000.0;
	        	  if(servingcustomer11.timeofjob<1000000000.0) {
	        		  servingcustomer11.serverremainder=servingcustomer11.timeofjob;
	        		  servingcustomer11.leavetime=servingcustomer11.timeofjob;
	        	  }
	        	  server11=true;
	        	 }
	         }
        	 if(exitcustomer.index<=15) {
	             System.out.println("------------------------------------------------------------------------");
	        	 System.out.println("FCFS: A Job in Server 1 needs more service time and is being booted to delayed queue Event has occurred Timer: "+timer1);
	   			 System.out.print(" Printing Departing Customer: "+exitcustomer.index);
	   			 System.out.print(" Job Time "+exitcustomer.timeofjob+" Arrival: "+exitcustomer.arrivaltime+" Remaining Job Time: "+exitcustomer.timeleft); 				  
	        	 System.out.println();
	        	 System.out.println("FCFS: Printing All Future Customers Current Customers Served: "+numberofcustomersserved1);
	        	 System.out.println("Timer: "+timer1);
	        	 if(servingcustomer11!=null) {
	            	 System.out.println("---");
	            	 System.out.print("FCFS Server 1: ");
	            	 System.out.print(" Customer Event Number :  "+servingcustomer11.index);
	    			 System.out.print(" Arrival Time: "+servingcustomer11.arrivaltime);
	    			 System.out.print(" Job Time: "+servingcustomer11.timeofjob);
	    			 System.out.print(" Remaining Job Time: "+servingcustomer11.timeleft);
	    			 System.out.print(" Exit Time: "+(Math.round((servingcustomer11.timeleft+timer1)*10000)/10000.0));
	    			 System.out.println();
	        	 }
	        	 if(servingcustomer21!=null) {
	            	 System.out.println("---");
	            	 System.out.print("FCFS Server 2: ");
	            	 System.out.print(" Customer Event Number :  "+servingcustomer21.index);
	    			 System.out.print(" Arrival Time: "+servingcustomer21.arrivaltime);
	    			 System.out.print(" Job Time: "+servingcustomer21.timeofjob);
	    			 System.out.print(" Remaining Job Time: "+servingcustomer21.timeleft);
	    			 System.out.print(" Exit Time: "+(Math.round((servingcustomer21.timeleft+timer1)*10000)/10000.0));
	    			 System.out.println();
	        	 }
	        	 if(cust1!=null) {
	            	 System.out.println("---");
	            	 System.out.print("Next Arriving FCFS Customer: ");
	            	 System.out.print(" Customer Event Number:  "+cust1.index);
	    			 System.out.print(" Arrival Time: "+cust1.arrivaltime);
	    			 System.out.print(" Job Time: "+cust1.timeofjob);
	    			 System.out.print(" Remaining Job Time (Same as Job Time): "+cust1.timeleft);
	    			 System.out.println();
	        	 }
						/*
						 * System.out.
						 * println("FCFS: Printing All Delayed Customers Current Customers Served: "
						 * +numberofcustomersserved1); System.out.println("Timer: "+timer1);
						 * if(customerarray1.size()==0) System.out.println("Delayed list is empty");
						 * for(int i=customerarray1.size()-1;0<=i;i--) { System.out.println("---");
						 * System.out.print("Customer Event Number :  "+customerarray1.get(i).index);
						 * System.out.print(" Arrival Time: "+customerarray1.get(i).arrivaltime);
						 * System.out.print(" Job Time: "+customerarray1.get(i).timeofjob);
						 * System.out.print(" Remaining Job Time: "+customerarray1.get(i).timeleft);
						 * System.out.println(); }
						 */
	        	 System.out.println("------------------------------------------------------------------------");	 
	            }
        	 }
        	 else if(servingcustomer11.timeinserver<servingcustomer11.leavetime) {
        	  servingcustomer11.serverremainder=Math.round((servingcustomer11.leavetime-servingcustomer11.timeinserver)*10000)/10000.0;
        	  //System.out.println("server 1");
        	 }
         }
         if(server21==true){
        	 double timeprogress21=Math.round((servingcustomer21.timecompleted+mintime1)*10000)/10000.0;
        	 servingcustomer21.timeinserver=Math.round((servingcustomer21.timeinserver+mintime1)*10000)/10000.0;
        	 servingcustomer21.timeleft=Math.round((servingcustomer21.timeofjob-timeprogress21)*10000)/10000.0;
        	 servingcustomer21.timecompleted=timeprogress21;
        	 if(servingcustomer21.timecompleted>=servingcustomer21.timeofjob) {
        		 double difference=Math.round((timeprogress21-servingcustomer21.timeofjob)*10000)/10000.0;
        		 servingcustomer21.exittime=Math.round((timer1-difference)*10000)/10000.0;
        		 servingcustomer21.leftservertime++;
    			 exittimearray1.add(servingcustomer21.exittime);
    			 finishedcustarray1.add(servingcustomer21);
    			 Customer exitcustomer=servingcustomer21;
    			 servingcustomer21=null;
    			 server21=false;
    			 diditchange1=true;
    			 numberofcustomersserved1++;
    			 if(customerarray1.size()!=0) {
    	              Customer poppedcust21=customerarray1.get(customerarray1.size()-1);
    	              customerarray1.remove(customerarray1.size()-1);
    	              while(poppedcust21==null && customerarray1.isEmpty()==false) {
    	            	  poppedcust21=customerarray1.remove(customerarray1.size()-1);
    	              }
    	              if(poppedcust21!=null) {
    	        	  servingcustomer21=poppedcust21;
    	        	  servingcustomer21.diditgoinside=true;
    	        	  servingcustomer21.serverremainder=1000000000.0;
    	        	  servingcustomer21.leavetime=1000000000.0;
    	        	  if(servingcustomer21.timeofjob<1000000000.0) { 
    	        		  servingcustomer21.serverremainder=servingcustomer21.timeofjob;
    	        		  servingcustomer21.leavetime=servingcustomer21.timeofjob;
    	        	  }
    	        	  server21=true;
    	        	 }
    	         }
    			 if(exitcustomer.index<=15) {
    	             System.out.println("------------------------------------------------------------------------");
    	        	 System.out.println("FCFS: Departing System from Server 2 Event has occurred Timer: "+exitcustomer.exittime);
    	   			 System.out.print(" Printing Departing Customer: "+exitcustomer.index);
    	   			 System.out.print(" Job Time "+exitcustomer.timeofjob+" Arrival: "+exitcustomer.arrivaltime); 				  
    	        	 System.out.println();
    	        	 System.out.println("FCFS: Printing All Future Customers Current Customers Served: "+numberofcustomersserved1);
    	        	 System.out.println("Timer: "+timer1);
    	        	 if(servingcustomer11!=null) {
    	            	 System.out.println("---");
    	            	 System.out.print("FCFS Server 1: ");
    	            	 System.out.print(" Customer Event Number :  "+servingcustomer11.index);
    	    			 System.out.print(" Arrival Time: "+servingcustomer11.arrivaltime);
    	    			 System.out.print(" Job Time: "+servingcustomer11.timeofjob);
    	    			 System.out.print(" Remaining Job Time: "+servingcustomer11.timeleft);
    	    			 System.out.print(" Exit Time: "+(Math.round((servingcustomer11.timeleft+timer1)*10000)/10000.0));
    	    			 System.out.println();
    	        	 }
    	        	 if(servingcustomer21!=null) {
    	            	 System.out.println("---");
    	            	 System.out.print("FCFS Server 2: ");
    	            	 System.out.print(" Customer Event Number :  "+servingcustomer21.index);
    	    			 System.out.print(" Arrival Time: "+servingcustomer21.arrivaltime);
    	    			 System.out.print(" Job Time: "+servingcustomer21.timeofjob);
    	    			 System.out.print(" Remaining Job Time: "+servingcustomer21.timeleft);
    	    			 System.out.print(" Exit Time: "+(Math.round((servingcustomer21.timeleft+timer1)*10000)/10000.0));
    	    			 System.out.println();
    	        	 }
    	        	 if(cust1!=null) {
    	            	 System.out.println("---");
    	            	 System.out.print("Next Arriving FCFS Customer: ");
    	            	 System.out.print(" Customer Event Number:  "+cust1.index);
    	    			 System.out.print(" Arrival Time: "+cust1.arrivaltime);
    	    			 System.out.print(" Job Time: "+cust1.timeofjob);
    	    			 System.out.print(" Remaining Job Time (Same as Job Time): "+cust1.timeleft);
    	    			 System.out.println();
    	        	 }
    	        	 System.out.println("FCFS: Printing All Delayed Customers Current Customers Served: "+numberofcustomersserved1);
    	        	 System.out.println("Timer: "+timer1);
    	        	 if(customerarray1.size()==0) System.out.println("Delayed list is empty");
    	        	 for(int i=customerarray1.size()-1;0<=i;i--) {
    	                	 System.out.println("---");
    	        			 System.out.print("Customer Event Number :  "+customerarray1.get(i).index);
    	        			 System.out.print(" Arrival Time: "+customerarray1.get(i).arrivaltime);
    	        			 System.out.print(" Job Time: "+customerarray1.get(i).timeofjob);
    	        			 System.out.print(" Remaining Job Time: "+customerarray1.get(i).timeleft);
    	        			 System.out.println();
    	        	 }
    	        	 System.out.println("------------------------------------------------------------------------");	 
    	            }
    		 }
        	 else if(servingcustomer21.timeinserver>=servingcustomer21.leavetime) {
        	 servingcustomer21.timeinserver=0.0;
        	 servingcustomer21.leavetime=0.0;
        	 servingcustomer21.leftservertime++;
             customerarray1.add(0,servingcustomer21);
             Customer exitcustomer=servingcustomer21;
        	 servingcustomer21=null;
        	 server21=false;
        	 if(customerarray1.size()!=0) {
	              Customer poppedcust21=customerarray1.get(customerarray1.size()-1);
	              customerarray1.remove(customerarray1.size()-1);
	              while(poppedcust21==null && customerarray1.isEmpty()==false) {
	            	  poppedcust21=customerarray1.remove(customerarray1.size()-1);
	              }
	              if(poppedcust21!=null) {
	        	  servingcustomer21=poppedcust21;
	        	  servingcustomer21.diditgoinside=true;
	        	  servingcustomer21.serverremainder=1000000000.0;
	        	  servingcustomer21.leavetime=1000000000.0;
	        	  if(servingcustomer21.timeofjob<1000000000.0) { 
	        		  servingcustomer21.serverremainder=servingcustomer21.timeofjob;
	        		  servingcustomer21.leavetime=servingcustomer21.timeofjob;
	        	  }
	        	  server21=true;
	        	 }
	         }
        	 if(exitcustomer.index<=15) {
	             System.out.println("------------------------------------------------------------------------");
	        	 System.out.println("FCFS: A Job in Server 2 needs more service time and is being booted to delayed queue Event has occurred Timer: "+timer1);
	   			 System.out.print(" Printing Departing Customer: "+exitcustomer.index);
	   			 System.out.print(" Job Time "+exitcustomer.timeofjob+" Arrival: "+exitcustomer.arrivaltime+" Remaining Job Time: "+exitcustomer.timeleft); 				  
	        	 System.out.println();
	        	 System.out.println("FCFS: Printing All Future Customers Current Customers Served: "+numberofcustomersserved1);
	        	 System.out.println("Timer: "+timer1);
	        	 if(servingcustomer11!=null) {
	            	 System.out.println("---");
	            	 System.out.print("FCFS Server 1: ");
	            	 System.out.print(" Customer Event Number :  "+servingcustomer11.index);
	    			 System.out.print(" Arrival Time: "+servingcustomer11.arrivaltime);
	    			 System.out.print(" Job Time: "+servingcustomer11.timeofjob);
	    			 System.out.print(" Remaining Job Time: "+servingcustomer11.timeleft);
	    			 System.out.print(" Exit Time: "+(Math.round((servingcustomer11.timeleft+timer1)*10000)/10000.0));
	    			 System.out.println();
	        	 }
	        	 if(servingcustomer21!=null) {
	            	 System.out.println("---");
	            	 System.out.print("FCFS Server 2: ");
	            	 System.out.print(" Customer Event Number :  "+servingcustomer21.index);
	    			 System.out.print(" Arrival Time: "+servingcustomer21.arrivaltime);
	    			 System.out.print(" Job Time: "+servingcustomer21.timeofjob);
	    			 System.out.print(" Remaining Job Time: "+servingcustomer21.timeleft);
	    			 System.out.print(" Exit Time: "+(Math.round((servingcustomer21.timeleft+timer1)*10000)/10000.0));
	    			 System.out.println();
	        	 }
	        	 if(cust1!=null) {
	            	 System.out.println("---");
	            	 System.out.print("Next Arriving FCFS Customer: ");
	            	 System.out.print(" Customer Event Number:  "+cust1.index);
	    			 System.out.print(" Arrival Time: "+cust1.arrivaltime);
	    			 System.out.print(" Job Time: "+cust1.timeofjob);
	    			 System.out.print(" Remaining Job Time (Same as Job Time): "+cust1.timeleft);
	    			 System.out.println();
	        	 }
						/*
						 * System.out.
						 * println("FCFS: Printing All Delayed Customers Current Customers Served: "
						 * +numberofcustomersserved1); System.out.println("Timer: "+timer1);
						 * if(customerarray1.size()==0) System.out.println("Delayed list is empty");
						 * for(int i=customerarray1.size()-1;0<=i;i--) { System.out.println("---");
						 * System.out.print("Customer Event Number :  "+customerarray1.get(i).index);
						 * System.out.print(" Arrival Time: "+customerarray1.get(i).arrivaltime);
						 * System.out.print(" Job Time: "+customerarray1.get(i).timeofjob);
						 * System.out.print(" Remaining Job Time: "+customerarray1.get(i).timeleft);
						 * System.out.println(); }
						 */
	        	 System.out.println("------------------------------------------------------------------------");	 
	            }
        	 }
        	 else if(servingcustomer21.timeinserver<servingcustomer21.leavetime) {
        	  servingcustomer21.serverremainder=Math.round((servingcustomer21.leavetime-servingcustomer21.timeinserver)*10000)/10000.0;
        	 }
         }
         if(server11==false) {
        	 if(customerarray1.size()!=0) {
              Customer poppedcust11=customerarray1.get(customerarray1.size()-1);
              customerarray1.remove(customerarray1.size()-1);
              while(poppedcust11==null && customerarray1.isEmpty()==false) {
            	  poppedcust11=customerarray1.remove(customerarray1.size()-1);
              }
              if(poppedcust11!=null) {
        	  servingcustomer11=poppedcust11;
        	  servingcustomer11.diditgoinside=true;
        	  servingcustomer11.serverremainder=1000000000.0;
        	  servingcustomer11.leavetime=1000000000.0;
        	  if(servingcustomer11.timeofjob<1000000000.0) {
        		  servingcustomer11.serverremainder=servingcustomer11.timeofjob;
        		  servingcustomer11.leavetime=servingcustomer11.timeofjob;
        	  }
        	  server11=true;
        	 }
        	}
         }
         if(server21==false) {
        	 if(customerarray1.size()!=0) {
              Customer poppedcust21=customerarray1.get(customerarray1.size()-1);
              customerarray1.remove(customerarray1.size()-1);
              while(poppedcust21==null && customerarray1.isEmpty()==false) {
            	  poppedcust21=customerarray1.remove(customerarray1.size()-1);
              }
              if(poppedcust21!=null) {
        	  servingcustomer21=poppedcust21;
        	  servingcustomer21.diditgoinside=true;
        	  servingcustomer21.serverremainder=1000000000.0;
        	  servingcustomer21.leavetime=1000000000.0;
        	  if(servingcustomer21.timeofjob<1000000000.0) { 
        		  servingcustomer21.serverremainder=servingcustomer21.timeofjob;
        		  servingcustomer21.leavetime=servingcustomer21.timeofjob;
        	  }
        	  server21=true;
        	 }
        	 }
         }
         int totalnumberofunserved1=0;
         int totalnumberofdelayed1=0;
          for(int i=0;i<customerarray1.size();i++) {
         	 if(customerarray1.get(i).diditgoinside==false) totalnumberofunserved1++;
         	 if(customerarray1.get(i).diditgoinside==true) totalnumberofdelayed1++;
          }
          if(timewhenintervalarrives1<=timer1){
         	 //jobtimearray1.add(cust1.timeofjob);
              //arrivaltimearray1.add(timewhenintervalarrives1);
        	  customerarray1.add(0,cust1);
        	  if(server11==false) {
             	 if(customerarray1.size()!=0) {
                   Customer poppedcust11=customerarray1.get(customerarray1.size()-1);
                   customerarray1.remove(customerarray1.size()-1);
                   while(poppedcust11==null && customerarray1.isEmpty()==false) {
                 	  poppedcust11=customerarray1.remove(customerarray1.size()-1);
                   }
                   if(poppedcust11!=null) {
             	  servingcustomer11=poppedcust11;
             	  servingcustomer11.diditgoinside=true;
             	  servingcustomer11.serverremainder=1000000000.0;
             	  servingcustomer11.leavetime=1000000000.0;
             	  if(servingcustomer11.timeofjob<1000000000.0) {
             		  servingcustomer11.serverremainder=servingcustomer11.timeofjob;
             		  servingcustomer11.leavetime=servingcustomer11.timeofjob;
             	  }
             	  server11=true;
             	 }
             	}
              }
              if(server21==false) {
             	 if(customerarray1.size()!=0) {
                   Customer poppedcust21=customerarray1.get(customerarray1.size()-1);
                   customerarray1.remove(customerarray1.size()-1);
                   while(poppedcust21==null && customerarray1.isEmpty()==false) {
                 	  poppedcust21=customerarray1.remove(customerarray1.size()-1);
                   }
                   if(poppedcust21!=null) {
             	  servingcustomer21=poppedcust21;
             	  servingcustomer21.diditgoinside=true;
             	  servingcustomer21.serverremainder=1000000000.0;
             	  servingcustomer21.leavetime=1000000000.0;
             	  if(servingcustomer21.timeofjob<1000000000.0) { 
             		  servingcustomer21.serverremainder=servingcustomer21.timeofjob;
             		  servingcustomer21.leavetime=servingcustomer21.timeofjob;
             	  }
             	  server21=true;
             	 }
             	 }
              }
              customernum1++;
              Customer oldcust=cust1;
              cust1=new Customer(customernum1);
              while(interval1==0.0) interval1=intervaltime();
              timewhenintervalarrives1=Math.round((timer1+interval1)*10000)/10000.0;
              cust1.arrivaltime=timewhenintervalarrives1;
              cust1.timeofjob=servicetime();
              cust1.timeleft=cust1.timeofjob;
              if(oldcust.index<=15) {
              System.out.println("------------------------------------------------------------------------");
          	 System.out.println("FCFS: Arrival Event has occurred Timer: "+timer1);
     			 System.out.print("Printing Arrived Customer: "+oldcust.index); 
     			 System.out.print(" Job Time "+oldcust.timeofjob+" Arrival: "+oldcust.arrivaltime); 				  
          	 System.out.println();
 	        	 System.out.println("FCFS: Printing All Future Customers, Current Customers Served: "+numberofcustomersserved1+" Current Event Number: "+oldcust.index);
 	        	 System.out.println("Timer: "+timer1);
 	        	 if(servingcustomer11!=null) {
 	            	 System.out.println("---");
 	            	 System.out.print("FCFS Server 1: ");
 	            	 System.out.print(" Customer Event Number :  "+servingcustomer11.index);
 	    			 System.out.print(" Arrival Time: "+servingcustomer11.arrivaltime);
 	    			 System.out.print(" Job Time: "+servingcustomer11.timeofjob);
 	    			 System.out.print(" Remaining Job Time: "+servingcustomer11.timeleft);
 	    			 System.out.print(" Exit Time: "+(Math.round((servingcustomer11.timeleft+timer1)*10000)/10000.0));
 	    			 System.out.println();
 	        	 }
 	        	 if(servingcustomer21!=null) {
 	            	 System.out.println("---");
 	            	 System.out.print("FCFS Server 2: ");
 	            	 System.out.print(" Customer Event Number :  "+servingcustomer21.index);
 	    			 System.out.print(" Arrival Time: "+servingcustomer21.arrivaltime);
 	    			 System.out.print(" Job Time: "+servingcustomer21.timeofjob);
 	    			 System.out.print(" Remaining Job Time: "+servingcustomer21.timeleft);
 	    			 System.out.print(" Exit Time: "+(Math.round((servingcustomer21.timeleft+timer1)*10000)/10000.0));
 	    			 System.out.println();
 	        	 }
 	        	 if(cust1!=null) {
 	            	 System.out.println("---");
 	            	 System.out.println("Next Arriving FCFS Customer: ");
 	            	 System.out.print(" Customer Event Number :  "+cust1.index);
 	    			 System.out.print(" Arrival Time: "+cust1.arrivaltime);
 	    			 System.out.print(" Job Time: "+cust1.timeofjob);
 	    			 System.out.print(" Remaining Job Time (Same as Job Time): "+cust1.timeleft);
 	    			 System.out.println();
 	        	 }
 	        	 System.out.println("FCFS: Printing All Delayed Customers, Current Customers Served: "+numberofcustomersserved1+" Current Event Number: "+oldcust.index);
 	        	 System.out.println("Timer: "+timer1);
 	        	if(customerarray1.size()==0) System.out.println("Delayed list is empty");
 	        	 for(int i=customerarray1.size()-1;0<=i;i--) {
 	                	 System.out.println("---");
 	        			 System.out.print("Customer Event Number :  "+customerarray1.get(i).index);
 	        			 System.out.print(" Arrival Time: "+customerarray1.get(i).arrivaltime);
 	        			 System.out.print(" Job Time: "+customerarray1.get(i).timeofjob);
 	        			 System.out.print(" Remaining Job Time: "+customerarray1.get(i).timeleft);
 	        			 System.out.println();
 	        	 }
 	        	 System.out.println("------------------------------------------------------------------------");
          }
              //customerarray1.add(0,oldcust); 
          }
         if(servingcustomer11!=null) mintimearray1.add(servingcustomer11.serverremainder);
         if(servingcustomer21!=null) mintimearray1.add(servingcustomer21.serverremainder);
         double untilinterval1= Math.round((timewhenintervalarrives1-timer1)*10000)/10000.0;
         //if(mintimearray1.isEmpty()==true) mintimearray.add(untilinterval1);
         mintimearray1.add(untilinterval1);
         mintime1=Collections.min(mintimearray1);
         newtime1=Math.round((timer1+mintime1)*10000)/10000.0;
         oldtime1=timer1;
         timer1=newtime1;
       }
       System.out.println("This prints the first 15 customers in FCFS (by index which is by order of entering system, not exit)");
       for(int i=1;i<=15;i++) {
    	 for(int j=0;j<finishedcustarray1.size();j++) {
    	    if(finishedcustarray1.get(j).index==i) {
    	      System.out.print("FCFS Customer Event Number (Index) "+finishedcustarray1.get(j).index);
    	      System.out.print(" Job Time "+finishedcustarray1.get(j).timeofjob+" Arrival: "+finishedcustarray1.get(j).arrivaltime+" Exit: "+finishedcustarray1.get(j).exittime);
    	      System.out.print(" Time in System excluding service: "+(Math.round((finishedcustarray1.get(j).exittime-finishedcustarray1.get(j).arrivaltime-finishedcustarray1.get(j).timeofjob)*10000.0)/10000.0));
    	      System.out.println(" ");
    	      break;
    	    }
    	 } 
       }
       System.out.println("The third method attempts to process 10,000 customers, debugging method with a quantum of 10");
       Boolean server1d=false;
       Boolean server2d=false;
       Customer servingcustomer1d=null;
       Customer servingcustomer2d=null;       
       int numberofcustomersservedd=0;
       int customernumd=0;
       double timerd=0.0;
       double oldtimed=0.0;
       double timewhenintervalarrivesd=intervaltime();
       double mintimed=0.0;
       double intervald=0.0;
       double newtimed=0.0;
       boolean diditchanged=false;
       ArrayList<Customer> customerarrayd= new ArrayList<Customer>();
       ArrayList<Double> arrivaltimearrayd=new ArrayList<Double>();
       ArrayList<Double> exittimearrayd=new ArrayList<Double>();
       ArrayList<Double> jobtimearrayd=new ArrayList<Double>();
       ArrayList<Customer> finishedcustarrayd=new ArrayList<Customer>();
       customernumd++;
       Customer custd=new Customer(customernumd);
       custd.arrivaltime=timewhenintervalarrivesd;
       custd.timeofjob=servicetime();
       custd.timeleft=custd.timeofjob;
       while(numberofcustomersservedd<10000) {
         ArrayList<Double> mintimearrayd=new ArrayList<Double>();
         diditchanged=false;
         
         if(server1d==true){
        	 double timeprogress1d=Math.round((servingcustomer1d.timecompleted+mintimed)*10000)/10000.0;
        	 servingcustomer1d.timeinserver=Math.round((servingcustomer1d.timeinserver+mintimed)*10000)/10000.0;
        	 servingcustomer1d.timeleft=Math.round((servingcustomer1d.timeofjob-timeprogress1d)*10000)/10000.0;
        	 servingcustomer1d.timecompleted=timeprogress1d;
        	 if(servingcustomer1d.timecompleted>=servingcustomer1d.timeofjob) {
        		 double difference=Math.round((timeprogress1d-servingcustomer1d.timeofjob)*10000)/10000.0;
        		 servingcustomer1d.exittime=Math.round((timerd-difference)*10000)/10000.0;
        		 servingcustomer1d.leftservertime++;
    			 exittimearrayd.add(servingcustomer1d.exittime);
    			 finishedcustarrayd.add(servingcustomer1d);
    			 Customer exitcustomer=servingcustomer1d;
    			 servingcustomer1d=null;
    			 server1d=false;
    			 diditchanged=true;
    			 numberofcustomersservedd++;
    			 if(customerarrayd.size()!=0) {
    	              Customer poppedcust1d=customerarrayd.get(customerarrayd.size()-1);
    	              customerarrayd.remove(customerarrayd.size()-1);
    	              while(poppedcust1d==null && customerarrayd.isEmpty()==false) {
    	            	  poppedcust1d=customerarrayd.remove(customerarrayd.size()-1);
    	              }
    	              if(poppedcust1d!=null) {
    	        	  servingcustomer1d=poppedcust1d;
    	        	  servingcustomer1d.diditgoinside=true;
    	        	  servingcustomer1d.serverremainder=10.0;
    	        	  servingcustomer1d.leavetime=10.0;
    	        	  if(servingcustomer1d.timeofjob<10.0) {
    	        		  servingcustomer1d.serverremainder=servingcustomer1d.timeofjob;
    	        		  servingcustomer1d.leavetime=servingcustomer1d.timeofjob;
    	        	  }
    	        	  server1d=true;
    	        	 }
    	         }
    			 if(exitcustomer.index<=15) {
    	             System.out.println("------------------------------------------------------------------------");
    	        	 System.out.println("Debug: Departing System from Server 1 Event has occurred Timer: "+exitcustomer.exittime);
    	   			 System.out.print(" Printing Departing Customer: "+exitcustomer.index);
    	   			 System.out.print(" Job Time "+exitcustomer.timeofjob+" Arrival: "+exitcustomer.arrivaltime); 				  
    	        	 System.out.println();
    	        	 System.out.println("Debug: Printing All Future Customers Current Customers Served: "+numberofcustomersservedd);
    	        	 System.out.println("Timer: "+timerd);
    	        	 if(servingcustomer1d!=null) {
    	            	 System.out.println("---");
    	            	 System.out.print("Debug Server 1: ");
    	            	 System.out.print(" Customer Event Number :  "+servingcustomer1d.index);
    	    			 System.out.print(" Arrival Time: "+servingcustomer1d.arrivaltime);
    	    			 System.out.print(" Job Time: "+servingcustomer1d.timeofjob);
    	    			 System.out.print(" Remaining Job Time: "+servingcustomer1d.timeleft);
    	    			 System.out.println();
    	        	 }
    	        	 if(servingcustomer2d!=null) {
    	            	 System.out.println("---");
    	            	 System.out.print("Debug Server 2: ");
    	            	 System.out.print(" Customer Event Number :  "+servingcustomer2d.index);
    	    			 System.out.print(" Arrival Time: "+servingcustomer2d.arrivaltime);
    	    			 System.out.print(" Job Time: "+servingcustomer2d.timeofjob);
    	    			 System.out.print(" Remaining Job Time: "+servingcustomer2d.timeleft);
    	    			 System.out.println();
    	        	 }
    	        	 if(custd!=null) {
    	            	 System.out.println("---");
    	            	 System.out.print("Next Arriving Debug Customer: ");
    	            	 System.out.print(" Customer Event Number:  "+custd.index);
    	    			 System.out.print(" Arrival Time: "+custd.arrivaltime);
    	    			 System.out.print(" Job Time: "+custd.timeofjob);
    	    			 System.out.print(" Remaining Job Time (Same as Job Time): "+custd.timeleft);
    	    			 System.out.println();
    	        	 }
    	        	 System.out.println("Debug: Printing All Delayed Customers Current Customers Served: "+numberofcustomersservedd);
    	        	 System.out.println("Timer: "+timerd);
    	        	 if(customerarrayd.size()==0) System.out.println("Delayed list is empty");
    	        	 for(int i=customerarrayd.size()-1;0<=i;i--) {
    	                	 System.out.println("---");
    	        			 System.out.print("Customer Event Number :  "+customerarrayd.get(i).index);
    	        			 System.out.print(" Arrival Time: "+customerarrayd.get(i).arrivaltime);
    	        			 System.out.print(" Job Time: "+customerarrayd.get(i).timeofjob);
    	        			 System.out.print(" Remaining Job Time: "+customerarrayd.get(i).timeleft);
    	        			 System.out.println();
    	        	 }
    	        	 System.out.println("------------------------------------------------------------------------");	 
    	            }
    		 }
        	 else if(servingcustomer1d.timeinserver>=servingcustomer1d.leavetime) {
        	 servingcustomer1d.timeinserver=0.0;
        	 servingcustomer1d.leavetime=0.0;
        	 servingcustomer1d.leftservertime++;
             customerarrayd.add(0,servingcustomer1d);
             Customer exitcustomer=servingcustomer1d;
        	 servingcustomer1d=null;
        	 server1d=false;
        	 if(customerarrayd.size()!=0) {
	              Customer poppedcust1d=customerarrayd.get(customerarrayd.size()-1);
	              customerarrayd.remove(customerarrayd.size()-1);
	              while(poppedcust1d==null && customerarrayd.isEmpty()==false) {
	            	  poppedcust1d=customerarrayd.remove(customerarrayd.size()-1);
	              }
	              if(poppedcust1d!=null) {
	        	  servingcustomer1d=poppedcust1d;
	        	  servingcustomer1d.diditgoinside=true;
	        	  servingcustomer1d.serverremainder=10.0;
	        	  servingcustomer1d.leavetime=10.0;
	        	  if(servingcustomer1d.timeofjob<10.0) {
	        		  servingcustomer1d.serverremainder=servingcustomer1d.timeofjob;
	        		  servingcustomer1d.leavetime=servingcustomer1d.timeofjob;
	        	  }
	        	  server1d=true;
	        	 }
	         }
        	 if(exitcustomer.index<=15) {
	             System.out.println("------------------------------------------------------------------------");
	        	 System.out.println("Debug: A Job in Server 1 needs more service time and is being booted to delayed queue Event has occurred Timer: "+timerd);
	   			 System.out.print(" Printing Departing Customer: "+exitcustomer.index);
	   			 System.out.print(" Job Time "+exitcustomer.timeofjob+" Arrival: "+exitcustomer.arrivaltime+" Remaining Job Time: "+exitcustomer.timeleft); 				  
	        	 System.out.println();
	        	 System.out.println("Debug: Printing All Future Customers Current Customers Served: "+numberofcustomersservedd);
	        	 System.out.println("Timer: "+timerd);
	        	 if(servingcustomer1d!=null) {
	            	 System.out.println("---");
	            	 System.out.print("Debug Server 1: ");
	            	 System.out.print(" Customer Event Number :  "+servingcustomer1d.index);
	    			 System.out.print(" Arrival Time: "+servingcustomer1d.arrivaltime);
	    			 System.out.print(" Job Time: "+servingcustomer1d.timeofjob);
	    			 System.out.print(" Remaining Job Time: "+servingcustomer1d.timeleft);
	    			 System.out.println();
	        	 }
	        	 if(servingcustomer2d!=null) {
	            	 System.out.println("---");
	            	 System.out.print("Debug Server 2: ");
	            	 System.out.print(" Customer Event Number :  "+servingcustomer2d.index);
	    			 System.out.print(" Arrival Time: "+servingcustomer2d.arrivaltime);
	    			 System.out.print(" Job Time: "+servingcustomer2d.timeofjob);
	    			 System.out.print(" Remaining Job Time: "+servingcustomer2d.timeleft);
	    			 System.out.println();
	        	 }
	        	 if(custd!=null) {
	            	 System.out.println("---");
	            	 System.out.print("Next Arriving Debug Customer: ");
	            	 System.out.print(" Customer Event Number:  "+custd.index);
	    			 System.out.print(" Arrival Time: "+custd.arrivaltime);
	    			 System.out.print(" Job Time: "+custd.timeofjob);
	    			 System.out.print(" Remaining Job Time (Same as Job Time): "+custd.timeleft);
	    			 System.out.println();
	        	 }
						/*
						 * System.out.
						 * println("Debug: Printing All Delayed Customers Current Customers Served: "
						 * +numberofcustomersservedd); System.out.println("Timer: "+timerd);
						 * if(customerarrayd.size()==0) System.out.println("Delayed list is empty");
						 * for(int i=customerarrayd.size()-1;0<=i;i--) { System.out.println("---");
						 * System.out.print("Customer Event Number :  "+customerarrayd.get(i).index);
						 * System.out.print(" Arrival Time: "+customerarrayd.get(i).arrivaltime);
						 * System.out.print(" Job Time: "+customerarrayd.get(i).timeofjob);
						 * System.out.print(" Remaining Job Time: "+customerarrayd.get(i).timeleft);
						 * System.out.println(); }
						 */
	        	 System.out.println("------------------------------------------------------------------------");	 
	            }
        	 }
        	 else if(servingcustomer1d.timeinserver<servingcustomer1d.leavetime) {
        	  servingcustomer1d.serverremainder=Math.round((servingcustomer1d.leavetime-servingcustomer1d.timeinserver)*10000)/10000.0;
        	  //System.out.println("server 1");
        	 }
         }
         if(server2d==true){
        	 double timeprogress2d=Math.round((servingcustomer2d.timecompleted+mintimed)*10000)/10000.0;
        	 servingcustomer2d.timeinserver=Math.round((servingcustomer2d.timeinserver+mintimed)*10000)/10000.0;
        	 servingcustomer2d.timeleft=Math.round((servingcustomer2d.timeofjob-timeprogress2d)*10000)/10000.0;
        	 servingcustomer2d.timecompleted=timeprogress2d;
        	 if(servingcustomer2d.timecompleted>=servingcustomer2d.timeofjob) {
        		 double difference=Math.round((timeprogress2d-servingcustomer2d.timeofjob)*10000)/10000.0;
        		 servingcustomer2d.exittime=Math.round((timerd-difference)*10000)/10000.0;
        		 servingcustomer2d.leftservertime++;
    			 exittimearrayd.add(servingcustomer2d.exittime);
    			 finishedcustarrayd.add(servingcustomer2d);
    			 Customer exitcustomer=servingcustomer2d;
    			 servingcustomer2d=null;
    			 server2d=false;
    			 diditchanged=true;
    			 numberofcustomersservedd++;
    			 if(customerarrayd.size()!=0) {
    	              Customer poppedcust2d=customerarrayd.get(customerarrayd.size()-1);
    	              customerarrayd.remove(customerarrayd.size()-1);
    	              while(poppedcust2d==null && customerarrayd.isEmpty()==false) {
    	            	  poppedcust2d=customerarrayd.remove(customerarrayd.size()-1);
    	              }
    	              if(poppedcust2d!=null) {
    	        	  servingcustomer2d=poppedcust2d;
    	        	  servingcustomer2d.diditgoinside=true;
    	        	  servingcustomer2d.serverremainder=10.0;
    	        	  servingcustomer2d.leavetime=10.0;
    	        	  if(servingcustomer2d.timeofjob<10.0) {
    	        		  servingcustomer2d.serverremainder=servingcustomer2d.timeofjob;
    	        		  servingcustomer2d.leavetime=servingcustomer2d.timeofjob;
    	        	  }
    	        	  server2d=true;
    	        	 }
    	         }
    			 if(exitcustomer.index<=15) {
    	             System.out.println("------------------------------------------------------------------------");
    	        	 System.out.println("Debug: Departing System from Server 2 Event has occurred Timer: "+exitcustomer.exittime);
    	   			 System.out.print(" Printing Departing Customer: "+exitcustomer.index);
    	   			 System.out.print(" Job Time "+exitcustomer.timeofjob+" Arrival: "+exitcustomer.arrivaltime); 				  
    	        	 System.out.println();
    	        	 System.out.println("Debug: Printing All Future Customers Current Customers Served: "+numberofcustomersservedd);
    	        	 System.out.println("Timer: "+timerd);
    	        	 if(servingcustomer1d!=null) {
    	            	 System.out.println("---");
    	            	 System.out.print("Debug Server 1: ");
    	            	 System.out.print(" Customer Event Number :  "+servingcustomer1d.index);
    	    			 System.out.print(" Arrival Time: "+servingcustomer1d.arrivaltime);
    	    			 System.out.print(" Job Time: "+servingcustomer1d.timeofjob);
    	    			 System.out.print(" Remaining Job Time: "+servingcustomer1d.timeleft);
    	    			 System.out.println();
    	        	 }
    	        	 if(servingcustomer2d!=null) {
    	            	 System.out.println("---");
    	            	 System.out.print("Debug Server 2: ");
    	            	 System.out.print(" Customer Event Number :  "+servingcustomer2d.index);
    	    			 System.out.print(" Arrival Time: "+servingcustomer2d.arrivaltime);
    	    			 System.out.print(" Job Time: "+servingcustomer2d.timeofjob);
    	    			 System.out.print(" Remaining Job Time: "+servingcustomer2d.timeleft);
    	    			 System.out.println();
    	        	 }
    	        	 if(custd!=null) {
    	            	 System.out.println("---");
    	            	 System.out.print("Next Arriving Debug Customer: ");
    	            	 System.out.print(" Customer Event Number:  "+custd.index);
    	    			 System.out.print(" Arrival Time: "+custd.arrivaltime);
    	    			 System.out.print(" Job Time: "+custd.timeofjob);
    	    			 System.out.print(" Remaining Job Time (Same as Job Time): "+custd.timeleft);
    	    			 System.out.println();
    	        	 }
    	        	 System.out.println("Debug: Printing All Delayed Customers Current Customers Served: "+numberofcustomersservedd);
    	        	 System.out.println("Timer: "+timerd);
    	        	 if(customerarrayd.size()==0) System.out.println("Delayed list is empty");
    	        	 for(int i=customerarrayd.size()-1;0<=i;i--) {
    	                	 System.out.println("---");
    	        			 System.out.print("Customer Event Number :  "+customerarrayd.get(i).index);
    	        			 System.out.print(" Arrival Time: "+customerarrayd.get(i).arrivaltime);
    	        			 System.out.print(" Job Time: "+customerarrayd.get(i).timeofjob);
    	        			 System.out.print(" Remaining Job Time: "+customerarrayd.get(i).timeleft);
    	        			 System.out.println();
    	        	 }
    	        	 System.out.println("------------------------------------------------------------------------");	 
    	            }
    		 }
        	 else if(servingcustomer2d.timeinserver>=servingcustomer2d.leavetime) {
        	 servingcustomer2d.timeinserver=0.0;
        	 servingcustomer2d.leavetime=0.0;
        	 servingcustomer2d.leftservertime++;
             customerarrayd.add(0,servingcustomer2d);
             Customer exitcustomer=servingcustomer2d;
        	 servingcustomer2d=null;
        	 server2d=false;
        	 if(customerarrayd.size()!=0) {
	              Customer poppedcust2d=customerarrayd.get(customerarrayd.size()-1);
	              customerarrayd.remove(customerarrayd.size()-1);
	              while(poppedcust2d==null && customerarrayd.isEmpty()==false) {
	            	  poppedcust2d=customerarrayd.remove(customerarrayd.size()-1);
	              }
	              if(poppedcust2d!=null) {
	        	  servingcustomer2d=poppedcust2d;
	        	  servingcustomer2d.diditgoinside=true;
	        	  servingcustomer2d.serverremainder=10.0;
	        	  servingcustomer2d.leavetime=10.0;
	        	  if(servingcustomer2d.timeofjob<10.0) {
	        		  servingcustomer2d.serverremainder=servingcustomer2d.timeofjob;
	        		  servingcustomer2d.leavetime=servingcustomer2d.timeofjob;
	        	  }
	        	  server2d=true;
	        	 }
	         }
        	 if(exitcustomer.index<=15) {
	             System.out.println("------------------------------------------------------------------------");
	        	 System.out.println("Debug: A Job in Server 2 needs more service time and is being booted to delayed queue Event has occurred Timer: "+timerd);
	   			 System.out.print(" Printing Departing Customer: "+exitcustomer.index);
	   			 System.out.print(" Job Time "+exitcustomer.timeofjob+" Arrival: "+exitcustomer.arrivaltime+" Remaining Job Time: "+exitcustomer.timeleft); 				  
	        	 System.out.println();
	        	 System.out.println("Debug: Printing All Future Customers Current Customers Served: "+numberofcustomersservedd);
	        	 System.out.println("Timer: "+timerd);
	        	 if(servingcustomer1d!=null) {
	            	 System.out.println("---");
	            	 System.out.print("Debug Server 1: ");
	            	 System.out.print(" Customer Event Number :  "+servingcustomer1d.index);
	    			 System.out.print(" Arrival Time: "+servingcustomer1d.arrivaltime);
	    			 System.out.print(" Job Time: "+servingcustomer1d.timeofjob);
	    			 System.out.print(" Remaining Job Time: "+servingcustomer1d.timeleft);
	    			 System.out.println();
	        	 }
	        	 if(servingcustomer2d!=null) {
	            	 System.out.println("---");
	            	 System.out.print("Debug Server 2: ");
	            	 System.out.print(" Customer Event Number :  "+servingcustomer2d.index);
	    			 System.out.print(" Arrival Time: "+servingcustomer2d.arrivaltime);
	    			 System.out.print(" Job Time: "+servingcustomer2d.timeofjob);
	    			 System.out.print(" Remaining Job Time: "+servingcustomer2d.timeleft);
	    			 System.out.println();
	        	 }
	        	 if(custd!=null) {
	            	 System.out.println("---");
	            	 System.out.print("Next Arriving Debug Customer: ");
	            	 System.out.print(" Customer Event Number:  "+custd.index);
	    			 System.out.print(" Arrival Time: "+custd.arrivaltime);
	    			 System.out.print(" Job Time: "+custd.timeofjob);
	    			 System.out.print(" Remaining Job Time (Same as Job Time): "+custd.timeleft);
	    			 System.out.println();
	        	 }
						/*
						 * System.out.
						 * println("Debug: Printing All Delayed Customers Current Customers Served: "
						 * +numberofcustomersservedd); System.out.println("Timer: "+timerd);
						 * if(customerarrayd.size()==0) System.out.println("Delayed list is empty");
						 * for(int i=customerarrayd.size()-1;0<=i;i--) { System.out.println("---");
						 * System.out.print("Customer Event Number :  "+customerarrayd.get(i).index);
						 * System.out.print(" Arrival Time: "+customerarrayd.get(i).arrivaltime);
						 * System.out.print(" Job Time: "+customerarrayd.get(i).timeofjob);
						 * System.out.print(" Remaining Job Time: "+customerarrayd.get(i).timeleft);
						 * System.out.println(); }
						 */
	        	 System.out.println("------------------------------------------------------------------------");	 
	            }
        	 }
        	 else if(servingcustomer2d.timeinserver<servingcustomer2d.leavetime) {
        	  servingcustomer2d.serverremainder=Math.round((servingcustomer2d.leavetime-servingcustomer2d.timeinserver)*10000)/10000.0;
        	 }
         }
         if(server1d==false) {
        	 if(customerarrayd.size()!=0) {
              Customer poppedcust1d=customerarrayd.get(customerarrayd.size()-1);
              customerarrayd.remove(customerarrayd.size()-1);
              while(poppedcust1d==null && customerarrayd.isEmpty()==false) {
            	  poppedcust1d=customerarrayd.remove(customerarrayd.size()-1);
              }
              if(poppedcust1d!=null) {
        	  servingcustomer1d=poppedcust1d;
        	  servingcustomer1d.diditgoinside=true;
        	  servingcustomer1d.serverremainder=10.0;
        	  servingcustomer1d.leavetime=10.0;
        	  if(servingcustomer1d.timeofjob<10.0) {
        		  servingcustomer1d.serverremainder=servingcustomer1d.timeofjob;
        		  servingcustomer1d.leavetime=servingcustomer1d.timeofjob;
        	  }
        	  server1d=true;
        	 }
        	}
         }
         if(server2d==false) {
        	 if(customerarrayd.size()!=0) {
              Customer poppedcust2d=customerarrayd.get(customerarrayd.size()-1);
              customerarrayd.remove(customerarrayd.size()-1);
              while(poppedcust2d==null && customerarrayd.isEmpty()==false) {
            	  poppedcust2d=customerarrayd.remove(customerarrayd.size()-1);
              }
              if(poppedcust2d!=null) {
        	  servingcustomer2d=poppedcust2d;
        	  servingcustomer2d.diditgoinside=true;
        	  servingcustomer2d.serverremainder=10.0;
        	  servingcustomer2d.leavetime=10.0;
        	  if(servingcustomer2d.timeofjob<10.0) { 
        		  servingcustomer2d.serverremainder=servingcustomer2d.timeofjob;
        		  servingcustomer2d.leavetime=servingcustomer2d.timeofjob;
        	  }
        	  server2d=true;
        	 }
        	 }
         }
         int totalnumberofunservedd=0;
         int totalnumberofdelayedd=0;
          for(int i=0;i<customerarrayd.size();i++) {
         	 if(customerarrayd.get(i).diditgoinside==false) totalnumberofunservedd++;
         	 if(customerarrayd.get(i).diditgoinside==true) totalnumberofdelayedd++;
          }
          if(timewhenintervalarrivesd<=timerd){
         	 //jobtimearrayd.add(custd.timeofjob);
              //arrivaltimearrayd.add(timewhenintervalarrivesd);
        	  customerarrayd.add(0,custd);  
        	  if(server1d==false) {
             	 if(customerarrayd.size()!=0) {
                   Customer poppedcust1d=customerarrayd.get(customerarrayd.size()-1);
                   customerarrayd.remove(customerarrayd.size()-1);
                   while(poppedcust1d==null && customerarrayd.isEmpty()==false) {
                 	  poppedcust1d=customerarrayd.remove(customerarrayd.size()-1);
                   }
                   if(poppedcust1d!=null) {
             	  servingcustomer1d=poppedcust1d;
             	  servingcustomer1d.diditgoinside=true;
             	  servingcustomer1d.serverremainder=10.0;
             	  servingcustomer1d.leavetime=10.0;
             	  if(servingcustomer1d.timeofjob<10.0) {
             		  servingcustomer1d.serverremainder=servingcustomer1d.timeofjob;
             		  servingcustomer1d.leavetime=servingcustomer1d.timeofjob;
             	  }
             	  server1d=true;
             	 }
             	}
              }
              if(server2d==false) {
             	 if(customerarrayd.size()!=0) {
                   Customer poppedcust2d=customerarrayd.get(customerarrayd.size()-1);
                   customerarrayd.remove(customerarrayd.size()-1);
                   while(poppedcust2d==null && customerarrayd.isEmpty()==false) {
                 	  poppedcust2d=customerarrayd.remove(customerarrayd.size()-1);
                   }
                   if(poppedcust2d!=null) {
             	  servingcustomer2d=poppedcust2d;
             	  servingcustomer2d.diditgoinside=true;
             	  servingcustomer2d.serverremainder=10.0;
             	  servingcustomer2d.leavetime=10.0;
             	  if(servingcustomer2d.timeofjob<10.0) { 
             		  servingcustomer2d.serverremainder=servingcustomer2d.timeofjob;
             		  servingcustomer2d.leavetime=servingcustomer2d.timeofjob;
             	  }
             	  server2d=true;
             	 }
             	 }
              }
              customernumd++;
              Customer oldcust=custd;
              custd=new Customer(customernumd);
              while(intervald==0.0) intervald=intervaltime();
              timewhenintervalarrivesd=Math.round((timerd+intervald)*10000)/10000.0;
              custd.arrivaltime=timewhenintervalarrivesd;
              custd.timeofjob=servicetime();
              custd.timeleft=custd.timeofjob;
              if(oldcust.index<=15) {
              System.out.println("------------------------------------------------------------------------");
          	 System.out.println("Debug: Arrival Event has occurred Timer: "+timerd);
     			 System.out.print("Printing Arrived Customer: "+oldcust.index);
     			 System.out.print(" Job Time "+oldcust.timeofjob+" Arrival: "+oldcust.arrivaltime); 				  
          	 System.out.println();
 	        	 System.out.println("Debug: Printing All Future Customers, Current Customers Served: "+numberofcustomersservedd+" Current Event Number: "+oldcust.index);
 	        	 System.out.println("Timer: "+timerd);
 	        	 if(servingcustomer1d!=null) {
 	            	 System.out.println("---");
 	            	 System.out.print("Debug Server 1: ");
 	            	 System.out.print(" Customer Event Number :  "+servingcustomer1d.index);
 	    			 System.out.print(" Arrival Time: "+servingcustomer1d.arrivaltime);
 	    			 System.out.print(" Job Time: "+servingcustomer1d.timeofjob);
 	    			 System.out.print(" Remaining Job Time: "+servingcustomer1d.timeleft);
 	    			 System.out.println();
 	        	 }
 	        	 if(servingcustomer2d!=null) {
 	            	 System.out.println("---");
 	            	 System.out.print("Debug Server 2: ");
 	            	 System.out.print(" Customer Event Number :  "+servingcustomer2d.index);
 	    			 System.out.print(" Arrival Time: "+servingcustomer2d.arrivaltime);
 	    			 System.out.print(" Job Time: "+servingcustomer2d.timeofjob);
 	    			 System.out.print(" Remaining Job Time: "+servingcustomer2d.timeleft);
 	    			 System.out.println();
 	        	 }
 	        	 if(custd!=null) {
 	            	 System.out.println("---");
 	            	 System.out.print("Next Arriving Debug Customer: ");
 	            	 System.out.print(" Customer Event Number :  "+custd.index);
 	    			 System.out.print(" Arrival Time: "+custd.arrivaltime);
 	    			 System.out.print(" Job Time: "+custd.timeofjob);
 	    			 System.out.print(" Remaining Job Time (Same as Job Time): "+custd.timeleft);
 	    			 System.out.println();
 	        	 }
 	        	 System.out.println("Debug: Printing All Delayed Customers, Current Customers Served: "+numberofcustomersservedd+" Current Event Number: "+oldcust.index);
 	        	 System.out.println("Timer: "+timerd);
 	        	if(customerarrayd.size()==0) System.out.println("Delayed list is empty");
 	        	 for(int i=customerarrayd.size()-1;0<=i;i--) {
 	                	 System.out.println("---");
 	        			 System.out.print(" Customer Event Number :  "+customerarrayd.get(i).index);
 	        			 System.out.print(" Arrival Time: "+customerarrayd.get(i).arrivaltime);
 	        			 System.out.print(" Job Time: "+customerarrayd.get(i).timeofjob);
 	        			 System.out.print(" Remaining Job Time: "+customerarrayd.get(i).timeleft);
 	        			 System.out.println();
 	        	 }
 	        	 System.out.println("------------------------------------------------------------------------");
          }
              //customerarrayd.add(0,oldcust);  
          }
         if(servingcustomer1d!=null) mintimearrayd.add(servingcustomer1d.serverremainder);
         if(servingcustomer2d!=null) mintimearrayd.add(servingcustomer2d.serverremainder);
         double untilintervald= Math.round((timewhenintervalarrivesd-timerd)*10000)/10000.0;
         //if(mintimearray1.isEmpty()==true) mintimearray.add(untilinterval1);
         mintimearrayd.add(untilintervald);
         mintimed=Collections.min(mintimearrayd);
         newtimed=Math.round((timerd+mintimed)*10000)/10000.0;
         oldtimed=timerd;
         timerd=newtimed;
       } 
       System.out.println("This prints the first 15 customers in Debug (by index which is order of entering system, not exit)");
       for(int i=1;i<=15;i++) {
    	 for(int j=0;j<finishedcustarrayd.size();j++) {
    	    if(finishedcustarrayd.get(j).index==i) {
    	      System.out.print("Debug Customer Event Number (Index) "+finishedcustarrayd.get(j).index);
    	      System.out.print(" Job Time "+finishedcustarrayd.get(j).timeofjob+" Arrival: "+finishedcustarrayd.get(j).arrivaltime+" Exit: "+finishedcustarrayd.get(j).exittime);
    	      System.out.print(" Time in System excluding service: "+(Math.round((finishedcustarrayd.get(j).exittime-finishedcustarrayd.get(j).arrivaltime-finishedcustarrayd.get(j).timeofjob)*10000.0)/10000.0));
    	      System.out.println(" ");
    	      break;
    	    }
    	 } 
       }
       double totaltimerr=0.0;
       double totaltimerfc=0.0;
       double totaltimerd=0.0;
       for(int i=0;i<10000;i++) {
      	 Customer currpos=finishedcustarray.get(i);
      	 Customer currpos1=finishedcustarray1.get(i);
      	 Customer currposd=finishedcustarrayd.get(i);
      	 double currtimerr=Math.round((currpos.exittime-currpos.arrivaltime-currpos.timeofjob)*10000.0)/10000.0;
      	 double currtimefc=Math.round((currpos1.exittime-currpos1.arrivaltime-currpos1.timeofjob)*10000.0)/10000.0;
      	 double currtimed=Math.round((currposd.exittime-currposd.arrivaltime-currposd.timeofjob)*10000.0)/10000.0;
         totaltimerr=Math.round((totaltimerr+currtimerr)*10000.0)/10000.0;
         totaltimerfc=Math.round((totaltimerfc+currtimefc)*10000.0)/10000.0;
         totaltimerd=Math.round((totaltimerd+currtimed)*10000.0)/10000.0;
       }
       System.out.println("Round Robin Average Time Without Service "+(Math.round((totaltimerr/10000.0)*10000.0)/10000.0));
       System.out.println("First Come First Serve Average Time Without Service "+(Math.round((totaltimerfc/10000.0)*10000.0)/10000.0));
       System.out.println("Debug Average Time Without Service "+(Math.round((totaltimerd/10000.0)*10000.0)/10000.0));
       System.out.println("Let's calculate the averages for each range");
       double rr0to7=0.0;
       int  rr0to7count=0;
       double rr7to14=0.0;
       int  rr7to14count=0;
       double rr14to21=0.0;
       int  rr14to21count=0;
       double rr21andup=0.0;
       int  rr21andupcount=0;
       double fc0to7=0.0;
       int  fc0to7count=0;
       double fc7to14=0.0;
       int  fc7to14count=0;
       double fc14to21=0.0;
       int  fc14to21count=0;
       double fc21andup=0.0;
       int  fc21andupcount=0;
       double d0to7=0.0;
       int  d0to7count=0;
       double d7to14=0.0;
       int  d7to14count=0;
       double d14to21=0.0;
       int  d14to21count=0;
       double d21andup=0.0;
       int  d21andupcount=0;
       for(int i=0;i<10000;i++) {
    	 Customer currpos=finishedcustarray.get(i);
    	 Customer currpos1=finishedcustarray1.get(i);
      	 Customer currposd=finishedcustarrayd.get(i);
    	 double currtimerr=Math.round((currpos.exittime-currpos.arrivaltime-currpos.timeofjob)*10000.0)/10000.0;
    	 double currtimefc=Math.round((currpos1.exittime-currpos1.arrivaltime-currpos1.timeofjob)*10000.0)/10000.0;
      	 double currtimed=Math.round((currposd.exittime-currposd.arrivaltime-currposd.timeofjob)*10000.0)/10000.0;
    	 if(currtimerr<=7.0) {
        	 rr0to7=Math.round((rr0to7+currtimerr)*10000.0)/10000.0;
        	 rr0to7count++;
         }
         if((currtimerr>7.0)&&(currtimerr<=14.0)) {
        	 rr7to14=Math.round((rr7to14+currtimerr)*10000.0)/10000.0;
        	 rr7to14count++;
         }
         if((currtimerr>14.0)&&(currtimerr<=21.0)) {
        	 rr14to21=Math.round((rr14to21+currtimerr)*10000.0)/10000.0;
             rr14to21count++;
         }
         if(currtimerr>21.0) {
        	 rr21andup=Math.round((rr21andup+currtimerr)*10000.0)/10000.0;
             rr21andupcount++;
         }
         if(currtimefc<=7.0) {
        	 fc0to7=Math.round((fc0to7+currtimefc)*10000.0)/10000.0;
        	 fc0to7count++;
         }
         if((currtimefc>7.0)&&(currtimefc<=14.0)) {
        	 fc7to14=Math.round((fc7to14+currtimefc)*10000.0)/10000.0;
        	 fc7to14count++;
         }
         if((currtimefc>14.0)&&(currtimefc<=21.0)) {
        	 fc14to21=Math.round((fc14to21+currtimefc)*10000.0)/10000.0;
             fc14to21count++;
         }
         if(currtimefc>21.0) {
        	 fc21andup=Math.round((fc21andup+currtimefc)*10000.0)/10000.0;
             fc21andupcount++;
         }
         if(currtimed<=7.0) {
        	 d0to7=Math.round((d0to7+currtimed)*10000.0)/10000.0;
        	 d0to7count++;
         }
         if((currtimed>7.0)&&(currtimed<=14.0)) {
        	 d7to14=Math.round((d7to14+currtimed)*10000.0)/10000.0;
        	 d7to14count++;
         }
         if((currtimed>14.0)&&(currtimed<=21.0)) {
        	 d14to21=Math.round((d14to21+currtimed)*10000.0)/10000.0;
             d14to21count++;
         }
         if(currtimed>21.0) {
        	 d21andup=Math.round((d21andup+currtimed)*10000.0)/10000.0;
             d21andupcount++;
         }  
       }
       System.out.println("RR average 0 to 7 "+(Math.round((rr0to7/rr0to7count)*10000.0)/10000.0));
       System.out.println("RR average 7 to 14 "+(Math.round((rr7to14/rr7to14count)*10000.0)/10000.0));
       System.out.println("RR average 14 to 21 "+(Math.round((rr14to21/rr14to21count)*10000.0)/10000.0));
       System.out.println("RR average 21 and up "+(Math.round((rr21andup/rr21andupcount)*10000.0)/10000.0));
       System.out.println("FCFS average 0 to 7 "+(Math.round((fc0to7/fc0to7count)*10000.0)/10000.0));
       System.out.println("FCFS average 7 to 14 "+(Math.round((fc7to14/fc7to14count)*10000.0)/10000.0));
       System.out.println("FCFS average 14 to 21 "+(Math.round((fc14to21/fc14to21count)*10000.0)/10000.0));
       System.out.println("FCFS average 21 and up "+(Math.round((fc21andup/fc21andupcount)*10000.0)/10000.0));
       System.out.println("Debug average 0 to 7 "+(Math.round((d0to7/d0to7count)*10000.0)/10000.0));
       System.out.println("Debug average 7 to 14 "+(Math.round((d7to14/d7to14count)*10000.0)/10000.0));
       System.out.println("Debug average 14 to 21 "+(Math.round((d14to21/d14to21count)*10000.0)/10000.0));
       System.out.println("Debug average 21 and up "+(Math.round((d21andup/d21andupcount)*10000.0)/10000.0));
	}
}