
public class Card {
  int id;
  String[] suitarray=new String[] {"DIAMONDS","HEARTS","CLUBS","SPADES"};
  String[] rankarray=new String[] {"ACE", "TWO", "THREE","FOUR","FIVE","SIX","SEVEN","EIGHT","NINE","TEN","JACK","QUEEN","KING"};
  String suit;
  String rank;
  int rankid;
  int suitid;
  public Card(int id1,int id2) {
	 this.id=(13*(id1-1))+id2;
	 this.suitid=id1;
	 this.rankid=id2;
	 this.rank=this.rankarray[id2-1];
	 this.suit=this.suitarray[id1-1];
  }
}
