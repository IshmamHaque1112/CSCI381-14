import java.util.*;
public class Main {
    int numberofstraights=0;
    public static ArrayList<Card> createlist(){
    	ArrayList<Integer> forbiddennumbers=new ArrayList<Integer>();
    	ArrayList<Card> returnedcards=new ArrayList<Card>();
    	for(int i=0;i<5;i++) {
    		Random roll=new Random();
    		int suit=(((int)(roll.nextInt(4)+1)));
    		int rank=(((int)(roll.nextInt(13)+1)));
    		int newid=(13*(suit-1))+rank;
    		while(forbiddennumbers.contains(newid)==true) {
    			//System.out.println(suit+" "+rank);
    			suit=(((int)(roll.nextInt(4)+1)));
        		rank=(((int)(roll.nextInt(13)+1)));
        		newid=(13*(suit-1))+rank;
    		}
    		Card newcard= new Card(suit,rank);
    		returnedcards.add(newcard);
    		forbiddennumbers.add(newid);
    	}
    	return returnedcards;
    }
    public static boolean isitStraight(ArrayList<Card> a) {
     boolean straightlefttoright=true;
     boolean straightrighttoleft=true;
     boolean isthereanace=false;
     int numberofsuits=0;
     int numberofaces=0;
     int aceindex=-1;
     ArrayList<Integer> suits=new ArrayList<Integer>();
     ArrayList<Integer> ranks=new ArrayList<Integer>();
     for(int i=0;i<5;i++) {
    	int currid=a.get(i).suitid;
    	if(suits.contains(currid)==false) {
    	 numberofsuits++;
    	 suits.add(currid);
    	}
     }
     //if(numberofsuits==1) return false;
     if(a.get(0).rankid==1) {
    	 isthereanace=true;
    	 numberofaces++;
    	 aceindex=0;
     }
     for(int i=1;i<5;i++) {
    	if(a.get(i).rankid==1) {
    	  isthereanace=true;
    	  numberofaces++;
    	  aceindex=i;
    	}
    	if(a.get(i-1).rankid<=a.get(i).rankid) straightrighttoleft=false;
    	if(a.get(i-1).rankid>=a.get(i).rankid) straightlefttoright=false;
    	if((a.get(i-1).rankid>=a.get(i).rankid)&&Math.abs(a.get(i-1).rankid-a.get(i).rankid)!=1) straightrighttoleft=false;
    	if((a.get(i-1).rankid<=a.get(i).rankid)&&Math.abs(a.get(i-1).rankid-a.get(i).rankid)!=1) straightlefttoright=false;
     }
     if(isthereanace==true&&straightrighttoleft==false&&straightlefttoright==false&&numberofaces==1) {
    	 boolean straightrl=true;
    	 boolean straightlr=true;
    	 for(int i=0;i<5;i++) {
    		if(a.get(i).rankid==1) ranks.add(14);
    		else ranks.add(a.get(i).rankid);
    	 }
    	 for(int i=1;i<5;i++) {
    	   if(ranks.get(i-1)<=ranks.get(i)) straightrl=false;
    	   if(ranks.get(i-1)>=ranks.get(i)) straightlr=false;
    	   if((ranks.get(i-1)>=ranks.get(i))&&Math.abs(ranks.get(i-1)-ranks.get(i))!=1) straightrl=false;
       	   if((ranks.get(i-1)<=ranks.get(i))&&Math.abs(ranks.get(i-1)-ranks.get(i))!=1) straightlr=false;
    	 }
    	 return straightrl || straightlr;
     }
	 return straightrighttoleft||straightlefttoright;
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Running 10000 times");
		int numberofstraights=0;
		for(int i=0;i<10000;i++) {
			ArrayList<Card> cardlist=createlist();
			if(isitStraight(cardlist)==true) {
			 numberofstraights++;
			 System.out.println();
			 System.out.println("Card Time unit "+i+" Straight "+numberofstraights);
			 for(int j=0;j<5;j++) {
				System.out.println("Card "+j+" Suit "+cardlist.get(j).suit+" Rank "+cardlist.get(j).rank);
			 }
			 //System.out.println();
			}
			if(i%1000==0) System.out.println("At index "+i+" Number of straights "+numberofstraights);
		}
		System.out.println("Number of straights after 10000 runs : "+numberofstraights);
		double straightsintotal=numberofstraights/10000.0;
		double straighttheoretical=10240.0/2598960.0;	
		System.out.println("Straight probability for this run : "+straightsintotal);
		System.out.println("Theoretical probability: "+straighttheoretical);

	}

}
